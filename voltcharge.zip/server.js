const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.DEFAULT_APP_PORT || 3000;

const HTML_CONTENT = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>VoltCharge - Mobile Recharge, Bills & Wallet</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #0D53FC;
      --primary-dark: #083BB5;
      --primary-light: #E0E7FF;
      --cyan: #00C6FF;
      --mint: #00C853;
      --amber: #FF9F1C;
      --coral: #FF4757;
      --bg: #F6F8FD;
      --surface: #FFFFFF;
      --surface-variant: #EEF2F9;
      --text: #131A29;
      --text-muted: #616F89;
      --border: #D8E2EE;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #090D16;
      color: var(--text);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 10px;
    }

    .phone-container {
      width: 100%;
      max-width: 440px;
      height: 92vh;
      max-height: 890px;
      background: var(--bg);
      border-radius: 36px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-shadow: 0 25px 60px rgba(0, 0, 0, 0.45), 0 0 0 10px #1E293B;
      position: relative;
    }

    /* Top App Header */
    .app-header {
      background: var(--surface);
      padding: 14px 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid var(--border);
      z-index: 10;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 800;
      font-size: 18px;
      color: var(--text);
    }

    .brand-icon {
      width: 32px;
      height: 32px;
      background: linear-gradient(135deg, var(--primary), var(--cyan));
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 18px;
    }

    .wallet-pill {
      background: rgba(13, 83, 252, 0.08);
      color: var(--primary);
      padding: 6px 12px;
      border-radius: 100px;
      font-size: 13px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
      border: 1px solid rgba(13, 83, 252, 0.15);
      transition: all 0.2s ease;
    }
    .wallet-pill:hover {
      background: rgba(13, 83, 252, 0.14);
    }

    /* Screen Views */
    .screen-view {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
      display: none;
      scrollbar-width: none;
    }
    .screen-view::-webkit-scrollbar {
      display: none;
    }
    .screen-view.active {
      display: block;
    }

    /* Bottom Navigation Bar */
    .bottom-nav {
      background: var(--surface);
      border-top: 1px solid var(--border);
      display: flex;
      justify-content: space-around;
      padding: 10px 6px;
      z-index: 10;
    }
    .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      color: var(--text-muted);
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      padding: 4px 12px;
      border-radius: 12px;
      transition: all 0.2s;
    }
    .nav-item.active {
      color: var(--primary);
      background: rgba(13, 83, 252, 0.08);
    }
    .nav-item svg {
      width: 20px;
      height: 20px;
      fill: currentColor;
    }

    /* Active Plan Alert Card */
    .active-plan-card {
      background: linear-gradient(135deg, #0D1B3E, #1E293B);
      color: white;
      border-radius: 22px;
      padding: 18px;
      margin-bottom: 16px;
      box-shadow: 0 10px 25px rgba(13, 27, 62, 0.2);
    }
    .plan-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    .op-tag {
      background: #0A2885;
      color: white;
      font-size: 10px;
      font-weight: 800;
      padding: 3px 8px;
      border-radius: 6px;
    }
    .expiry-badge {
      background: rgba(255, 71, 87, 0.25);
      color: #FF6B81;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 6px;
    }
    .progress-bar-bg {
      background: rgba(255, 255, 255, 0.15);
      height: 6px;
      border-radius: 3px;
      margin: 8px 0 14px 0;
      overflow: hidden;
    }
    .progress-bar-fill {
      background: var(--cyan);
      height: 100%;
      width: 90%;
      border-radius: 3px;
    }
    .card-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .btn-sm-primary {
      background: var(--primary);
      color: white;
      border: none;
      padding: 7px 14px;
      border-radius: 10px;
      font-weight: 700;
      font-size: 12px;
      cursor: pointer;
    }

    /* Input Card */
    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 16px;
      margin-bottom: 16px;
    }
    .card-title {
      font-weight: 700;
      font-size: 15px;
      margin-bottom: 12px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .form-input {
      width: 100%;
      padding: 12px 14px;
      border-radius: 14px;
      border: 1.5px solid var(--border);
      font-size: 15px;
      font-weight: 600;
      color: var(--text);
      outline: none;
      transition: border 0.2s;
      background: #FAFBFE;
    }
    .form-input:focus {
      border-color: var(--primary);
      background: white;
    }

    .btn-block-primary {
      width: 100%;
      padding: 14px;
      background: var(--primary);
      color: white;
      border: none;
      border-radius: 14px;
      font-weight: 700;
      font-size: 15px;
      cursor: pointer;
      margin-top: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: background 0.2s;
    }
    .btn-block-primary:hover {
      background: var(--primary-dark);
    }

    /* Grid Services */
    .service-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
      margin-bottom: 16px;
    }
    .service-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
      text-align: center;
    }
    .service-icon-box {
      width: 52px;
      height: 52px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      margin-bottom: 6px;
      transition: transform 0.2s;
    }
    .service-item:hover .service-icon-box {
      transform: translateY(-2px);
    }
    .service-label {
      font-size: 11px;
      font-weight: 600;
      color: var(--text);
    }

    /* Horizontal scroll row */
    .scroll-row {
      display: flex;
      gap: 12px;
      overflow-x: auto;
      scrollbar-width: none;
      padding-bottom: 4px;
      margin-bottom: 16px;
    }
    .scroll-row::-webkit-scrollbar {
      display: none;
    }

    .beneficiary-card {
      min-width: 150px;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 18px;
      padding: 12px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      cursor: pointer;
    }
    .beneficiary-avatar {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      background: rgba(13, 83, 252, 0.1);
      color: var(--primary);
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 11px;
      margin-bottom: 8px;
    }

    .offer-card {
      min-width: 240px;
      border-radius: 18px;
      padding: 14px;
      color: white;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 110px;
    }

    /* Plan Cards */
    .filter-chips {
      display: flex;
      gap: 8px;
      overflow-x: auto;
      scrollbar-width: none;
      margin-bottom: 12px;
    }
    .chip {
      padding: 6px 14px;
      border-radius: 100px;
      background: var(--surface);
      border: 1px solid var(--border);
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
      cursor: pointer;
    }
    .chip.active {
      background: var(--primary);
      color: white;
      border-color: var(--primary);
    }

    .plan-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 16px;
      margin-bottom: 12px;
      transition: all 0.2s;
    }
    .plan-card.selected {
      border-color: var(--primary);
      box-shadow: 0 4px 15px rgba(13, 83, 252, 0.12);
    }
    .plan-price-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 10px;
    }
    .price-lg {
      font-size: 24px;
      font-weight: 800;
      color: var(--text);
    }
    .per-day {
      font-size: 11px;
      font-weight: 600;
      color: var(--text-muted);
      background: var(--surface-variant);
      padding: 2px 6px;
      border-radius: 4px;
      margin-left: 6px;
    }
    .plan-specs {
      display: flex;
      justify-content: space-between;
      background: #F7F9FD;
      padding: 8px 12px;
      border-radius: 12px;
      margin: 10px 0;
      font-size: 12px;
    }
    .spec-item {
      display: flex;
      flex-direction: column;
    }
    .spec-title {
      font-size: 9px;
      font-weight: 700;
      color: var(--text-muted);
    }
    .spec-val {
      font-weight: 700;
      color: var(--text);
    }

    /* Modal / Sheets */
    .modal-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(4px);
      z-index: 50;
      display: none;
      align-items: flex-end;
      justify-content: center;
    }
    .modal-overlay.active {
      display: flex;
    }
    .modal-sheet {
      background: var(--surface);
      width: 100%;
      border-radius: 28px 28px 0 0;
      padding: 22px;
      max-height: 85%;
      overflow-y: auto;
      animation: slideUp 0.3s ease;
    }
    @keyframes slideUp {
      from { transform: translateY(100%); }
      to { transform: translateY(0); }
    }

    /* Scratch Canvas */
    .scratch-box {
      width: 220px;
      height: 220px;
      border-radius: 20px;
      margin: 16px auto;
      position: relative;
      overflow: hidden;
      border: 2px dashed var(--amber);
      background: linear-gradient(135deg, #FFF6E5, #FFE7B3);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
    }
    #scratchCanvas {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      cursor: crosshair;
    }

    /* Success Screen */
    .success-icon-wrap {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: rgba(0, 200, 83, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 18px auto;
    }
    .success-icon {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: var(--mint);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 30px;
    }

    .preset-chip {
      padding: 8px 12px;
      border-radius: 10px;
      background: var(--surface-variant);
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      text-align: center;
    }
    .preset-chip:hover {
      background: rgba(13, 83, 252, 0.12);
      color: var(--primary);
    }
  </style>
</head>
<body>

<div class="phone-container">
  <!-- Top App Header -->
  <div class="app-header">
    <div class="brand-logo" onclick="switchTab('home')">
      <div class="brand-icon">⚡</div>
      <span>VoltCharge</span>
    </div>
    <div class="wallet-pill" onclick="openWalletModal()">
      <span>₹</span>
      <span id="walletBalanceTop">450.00</span>
      <span style="font-weight:bold;">+</span>
    </div>
  </div>

  <!-- SCREEN 1: HOME SCREEN -->
  <div id="screen-home" class="screen-view active">
    <!-- Active Plan Status Card -->
    <div class="active-plan-card">
      <div class="plan-header">
        <div style="display:flex; align-items:center; gap:8px;">
          <span class="op-tag">JIO</span>
          <span style="font-size:14px; font-weight:700;">9876543210</span>
        </div>
        <span class="expiry-badge">Expires in 2 Days</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:12px;">
        <span style="color:rgba(255,255,255,0.7);">Today's Data Usage</span>
        <span style="color:var(--cyan); font-weight:700;">⚡ True 5G Active</span>
      </div>
      <div class="progress-bar-bg">
        <div class="progress-bar-fill"></div>
      </div>
      <div class="card-footer">
        <span style="font-size:12px; color:rgba(255,255,255,0.85);">1.8 GB remaining of 2.0 GB</span>
        <button class="btn-sm-primary" onclick="quickRechargePrimary()">Recharge Now</button>
      </div>
    </div>

    <!-- Quick Mobile Recharge Input -->
    <div class="card">
      <div class="card-title">
        <span>Instant Mobile Recharge</span>
        <span style="font-size:10px; font-weight:800; color:var(--mint); background:rgba(0,200,83,0.12); padding:2px 6px; border-radius:4px;">1-TAP 5G</span>
      </div>
      <input type="tel" id="homeMobileInput" class="form-input" placeholder="Enter 10-digit mobile number" value="9876543210" maxlength="10">
      <button class="btn-block-primary" onclick="goToPlansFromHome()">Browse Plans & Offers →</button>
    </div>

    <!-- Utility Bills Hub Banner -->
    <div style="background:linear-gradient(135deg, #0F172A, #1E3A8A); border-radius:20px; padding:16px; color:white; margin-bottom:16px; cursor:pointer; border:1px solid rgba(13,83,252,0.4);" onclick="openUtilityDashboard('Electricity')">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:12px;">
          <div style="width:42px; height:42px; border-radius:50%; background:linear-gradient(135deg, #F59E0B, #00C6FF); display:flex; align-items:center; justify-content:center; font-size:22px;">⚡</div>
          <div>
            <div style="font-weight:800; font-size:15px; display:flex; align-items:center; gap:6px;">
              <span>Utility Bills Hub</span>
              <span style="background:var(--mint); color:white; font-size:9px; font-weight:800; padding:1px 5px; border-radius:4px;">BBPS</span>
            </div>
            <div style="font-size:11px; opacity:0.85;">Electricity • Piped Gas • Water • LPG</div>
            <div style="font-size:11px; color:var(--cyan); font-weight:600;">Fetch due bill with Consumer ID →</div>
          </div>
        </div>
        <button class="btn-sm-primary">Fetch</button>
      </div>
    </div>

    <!-- Recharge & Bill Pay Services Grid -->
    <div style="font-weight:700; font-size:14px; margin-bottom:10px;">Recharge & Bill Pay</div>
    <div class="service-grid">
      <div class="service-item" onclick="openService('Prepaid Mobile')">
        <div class="service-icon-box" style="background:rgba(13,83,252,0.12); color:var(--primary);">📱</div>
        <span class="service-label">Prepaid</span>
      </div>
      <div class="service-item" onclick="openService('Postpaid Bill')">
        <div class="service-icon-box" style="background:rgba(2,132,199,0.12); color:#0284C7;">📄</div>
        <span class="service-label">Postpaid</span>
      </div>
      <div class="service-item" onclick="openService('DTH TV')">
        <div class="service-icon-box" style="background:rgba(239,68,68,0.12); color:#EF4444;">📺</div>
        <span class="service-label">DTH TV</span>
      </div>
      <div class="service-item" onclick="openService('FASTag Recharge')">
        <div class="service-icon-box" style="background:rgba(16,185,129,0.12); color:#10B981;">🚗</div>
        <span class="service-label">FASTag</span>
      </div>
      <div class="service-item" onclick="openUtilityDashboard('Electricity')">
        <div class="service-icon-box" style="background:rgba(245,158,11,0.12); color:#F59E0B;">⚡</div>
        <span class="service-label">Electricity</span>
      </div>
      <div class="service-item" onclick="openUtilityDashboard('Piped Gas')">
        <div class="service-icon-box" style="background:rgba(0,137,123,0.12); color:#00897B;">🔥</div>
        <span class="service-label">Piped Gas</span>
      </div>
      <div class="service-item" onclick="openUtilityDashboard('Water')">
        <div class="service-icon-box" style="background:rgba(2,136,209,0.12); color:#0288D1;">💧</div>
        <span class="service-label">Water</span>
      </div>
      <div class="service-item" onclick="openUtilityDashboard('LPG Gas')">
        <div class="service-icon-box" style="background:rgba(230,74,25,0.12); color:#E64A19;">🛢️</div>
        <span class="service-label">LPG Gas</span>
      </div>
    </div>

    <!-- Recent / Saved Contacts -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <span style="font-weight:700; font-size:14px;">Recent & Saved</span>
      <span style="font-size:12px; color:var(--text-muted);">4 Contacts</span>
    </div>
    <div class="scroll-row">
      <div class="beneficiary-card" onclick="repeatBeneficiary('9876543210', 'Jio', 349)">
        <div class="beneficiary-avatar">JIO</div>
        <div style="font-size:13px; font-weight:700;">My Primary</div>
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">9876543210</div>
        <button class="btn-sm-primary" style="width:100%;">₹349</button>
      </div>
      <div class="beneficiary-card" onclick="repeatBeneficiary('9810012345', 'Airtel', 859)">
        <div class="beneficiary-avatar" style="color:#EE1C25; background:rgba(238,28,37,0.1);">AIR</div>
        <div style="font-size:13px; font-weight:700;">Mom's Phone</div>
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">9810012345</div>
        <button class="btn-sm-primary" style="width:100%;">₹859</button>
      </div>
      <div class="beneficiary-card" onclick="repeatBeneficiary('1029384756', 'Tata Play', 450)">
        <div class="beneficiary-avatar" style="color:#E50914; background:rgba(229,9,20,0.1);">DTH</div>
        <div style="font-size:13px; font-weight:700;">Living Room TV</div>
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">Tata Play</div>
        <button class="btn-sm-primary" style="width:100%;">₹450</button>
      </div>
      <div class="beneficiary-card" onclick="repeatBeneficiary('DL 01 AA 1008', 'FASTag', 500)">
        <div class="beneficiary-avatar" style="color:#00B9F5; background:rgba(0,185,245,0.1);">CAR</div>
        <div style="font-size:13px; font-weight:700;">Honda City</div>
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">FASTag</div>
        <button class="btn-sm-primary" style="width:100%;">₹500</button>
      </div>
    </div>

    <!-- Offers Carousel -->
    <div style="font-weight:700; font-size:14px; margin-bottom:10px;">Exclusive Deals</div>
    <div class="scroll-row">
      <div class="offer-card" style="background:linear-gradient(135deg, #0D53FC, #00C6FF);">
        <span style="background:rgba(255,255,255,0.25); padding:2px 8px; border-radius:6px; font-size:10px; font-weight:800; width:fit-content;">FLAT ₹50 OFF</span>
        <div>
          <div style="font-size:15px; font-weight:800;">Use Code VOLT50</div>
          <div style="font-size:11px; opacity:0.85;">On recharges of ₹299 and above</div>
        </div>
      </div>
      <div class="offer-card" style="background:linear-gradient(135deg, #6C5CE7, #B53471);">
        <span style="background:rgba(255,255,255,0.25); padding:2px 8px; border-radius:6px; font-size:10px; font-weight:800; width:fit-content;">OTT BUNDLES</span>
        <div>
          <div style="font-size:15px; font-weight:800;">Hotstar + 5G Free</div>
          <div style="font-size:11px; opacity:0.85;">Quarterly 2GB/day recharge pack</div>
        </div>
      </div>
    </div>
  </div>

  <!-- SCREEN 2: PLAN SELECTOR -->
  <div id="screen-plans" class="screen-view">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
      <div>
        <div style="font-weight:800; font-size:16px;" id="planHeaderNumber">9876543210</div>
        <div style="font-size:12px; color:var(--primary); font-weight:700; cursor:pointer;" onclick="switchOperator()">
          <span id="planHeaderOperator">Jio</span> • <span id="planHeaderCircle">Delhi NCR</span> ▾
        </div>
      </div>
      <button class="chip" onclick="switchTab('home')">Change</button>
    </div>

    <!-- Search Input -->
    <input type="text" id="planSearchInput" class="form-input" placeholder="Search ₹, 5G, data or OTT..." oninput="filterPlans()" style="margin-bottom:8px;">

    <!-- Filter Dimension Rows -->
    <div style="font-size:11px; font-weight:700; color:var(--text-muted); margin-bottom:4px;">Data Allowance:</div>
    <div class="filter-chips" style="margin-bottom:6px;">
      <div class="chip active" id="chip-data-ALL" onclick="setDataFilter('ALL', this)">All Data</div>
      <div class="chip" id="chip-data-1.5" onclick="setDataFilter('1.5', this)">1.5 GB/d</div>
      <div class="chip" id="chip-data-2" onclick="setDataFilter('2', this)">2 GB/d</div>
      <div class="chip" id="chip-data-5G" onclick="setDataFilter('5G', this)">⚡ True 5G</div>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
      <span style="font-size:11px; font-weight:700; color:var(--text-muted);">Validity & Price:</span>
      <span style="font-size:11px; font-weight:700; color:var(--primary); cursor:pointer;" onclick="resetPlanFilters()">Reset Filters</span>
    </div>
    <div class="filter-chips" style="margin-bottom:12px;">
      <div class="chip active" id="chip-val-ALL" onclick="setValFilter('ALL', this)">All Validity</div>
      <div class="chip" id="chip-val-28" onclick="setValFilter('28', this)">28 Days</div>
      <div class="chip" id="chip-val-84" onclick="setValFilter('84', this)">84-90 Days</div>
      <div class="chip" id="chip-val-365" onclick="setValFilter('365', this)">365 Days</div>
      <div class="chip" id="chip-price-mid" onclick="setPriceFilter('MID', this)">₹200 - ₹500</div>
      <div class="chip" id="chip-price-high" onclick="setPriceFilter('HIGH', this)">₹500+</div>
    </div>

    <!-- Plans List Container -->
    <div id="plansList"></div>
  </div>

  <!-- SCREEN 3: CHECKOUT SCREEN -->
  <div id="screen-checkout" class="screen-view">
    <div style="font-size:18px; font-weight:800; margin-bottom:14px;">Review & Payment</div>

    <!-- Plan Summary Card -->
    <div class="card">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div style="font-size:16px; font-weight:800;" id="checkoutTargetNum">9876543210</div>
          <div style="font-size:12px; color:var(--text-muted);" id="checkoutOpInfo">Jio • Delhi NCR Prepaid</div>
        </div>
        <div style="font-size:22px; font-weight:800; color:var(--primary);" id="checkoutBaseAmount">₹349</div>
      </div>
      <div style="font-size:13px; color:var(--text); margin-top:8px; font-weight:600;" id="checkoutPlanDesc">2 GB/day + Unlimited True 5G + JioCinema</div>
      <div style="display:flex; gap:12px; font-size:12px; color:var(--text-muted); margin-top:8px;">
        <span id="checkoutValidity">⏳ 28 Days</span>
        <span id="checkoutData">📶 2 GB/day</span>
        <span>📞 Truly Unlimited</span>
      </div>
    </div>

    <!-- Coupon Apply Box -->
    <div class="card" style="cursor:pointer;" onclick="openCouponModal()">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:10px;">
          <span style="font-size:20px;">🎟️</span>
          <div>
            <div style="font-weight:700; font-size:14px;" id="appliedCouponTitle">Apply Promo Code</div>
            <div style="font-size:11px; color:var(--text-muted);" id="appliedCouponSub">Tap to save up to ₹50 or get cashbacks</div>
          </div>
        </div>
        <span style="font-size:12px; color:var(--primary); font-weight:700;">APPLY</span>
      </div>
    </div>

    <!-- Wallet Balance Toggle -->
    <div class="card">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:10px;">
          <span style="font-size:20px;">💼</span>
          <div>
            <div style="font-weight:700; font-size:14px;">Volt Wallet Balance</div>
            <div style="font-size:12px; color:var(--mint); font-weight:600;">Available: ₹<span id="checkoutWalletBal">450.00</span></div>
          </div>
        </div>
        <input type="checkbox" id="walletCheckbox" onchange="updateCheckoutTotal()" style="width:20px; height:20px; accent-color:var(--primary);">
      </div>
    </div>

    <!-- Price Breakdown Card -->
    <div class="card">
      <div style="font-size:13px; font-weight:700; margin-bottom:10px;">Payment Breakdown</div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
        <span style="color:var(--text-muted);">Recharge Pack</span>
        <span id="billPackAmt">₹349</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px; color:var(--mint); display:none;" id="billCouponRow">
        <span>Coupon Discount</span>
        <span id="billCouponAmt">-₹0</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px; color:var(--primary); display:none;" id="billWalletRow">
        <span>Volt Wallet Used</span>
        <span id="billWalletAmt">-₹0</span>
      </div>
      <div style="border-top:1px solid var(--border); margin:8px 0; padding-top:8px; display:flex; justify-content:space-between; font-weight:800; font-size:16px;">
        <span>Final Payable</span>
        <span style="color:var(--primary);" id="billFinalPayable">₹349</span>
      </div>
    </div>

    <!-- Payment Methods -->
    <div style="font-weight:700; font-size:13px; margin-bottom:8px;">Choose Payment Mode</div>
    <div class="card" style="padding:10px;">
      <label style="display:flex; align-items:center; gap:10px; padding:8px 0; cursor:pointer;">
        <input type="radio" name="payMethod" checked style="accent-color:var(--primary);">
        <span style="font-size:18px;">📱</span>
        <div>
          <div style="font-weight:700; font-size:13px;">Google Pay / PhonePe UPI</div>
          <div style="font-size:11px; color:var(--text-muted);">Instant 1-tap PIN verification</div>
        </div>
      </label>
      <label style="display:flex; align-items:center; gap:10px; padding:8px 0; border-top:1px solid var(--border); cursor:pointer;">
        <input type="radio" name="payMethod" style="accent-color:var(--primary);">
        <span style="font-size:18px;">💳</span>
        <div>
          <div style="font-weight:700; font-size:13px;">Debit / Credit Card</div>
          <div style="font-size:11px; color:var(--text-muted);">Visa, MasterCard, RuPay</div>
        </div>
      </label>
    </div>

    <button class="btn-block-primary" onclick="startPaymentProcess()" id="payBtn">Proceed to Pay ₹349</button>
  </div>

  <!-- SCREEN 4: SUCCESS RECEIPT -->
  <div id="screen-success" class="screen-view">
    <div class="success-icon-wrap">
      <div class="success-icon">✓</div>
    </div>
    <div style="text-align:center; font-size:22px; font-weight:800; margin-bottom:4px;">Recharge Successful!</div>
    <div style="text-align:center; font-size:28px; font-weight:800; color:var(--primary);" id="successAmtDisplay">₹349</div>
    <div style="text-align:center; font-size:13px; color:var(--text-muted); margin-bottom:16px;" id="successSubDisplay">Jio • 9876543210</div>

    <!-- Scratch Card Won Banner -->
    <div style="background:linear-gradient(135deg, #6C5CE7, #00C6FF); border-radius:18px; padding:14px; color:white; display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; cursor:pointer;" onclick="switchTab('rewards')">
      <div style="display:flex; align-items:center; gap:10px;">
        <span style="font-size:24px;">🎁</span>
        <div>
          <div style="font-weight:800; font-size:14px;">Reward Card Unlocked!</div>
          <div style="font-size:11px; opacity:0.9;">Scratch now to reveal cashback</div>
        </div>
      </div>
      <button class="btn-sm-primary" style="background:white; color:#6C5CE7;">Scratch</button>
    </div>

    <!-- Receipt Card -->
    <div class="card">
      <div style="font-size:13px; font-weight:700; color:var(--text-muted); margin-bottom:10px;">Transaction Details</div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
        <span style="color:var(--text-muted);">Txn ID</span>
        <span style="font-weight:700;" id="successTxnId">VC-98471201</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
        <span style="color:var(--text-muted);">Operator Ref</span>
        <span style="font-weight:700;" id="successRefId">JIO-492019</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
        <span style="color:var(--text-muted);">Pack Validity</span>
        <span style="font-weight:700;" id="successValidity">28 Days</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
        <span style="color:var(--text-muted);">Payment Mode</span>
        <span style="font-weight:700;" id="successPaymentMode">Google Pay UPI</span>
      </div>
      <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
        <span style="color:var(--text-muted);">Status</span>
        <span style="font-weight:700; color:var(--mint);">SUCCESS</span>
      </div>
    </div>

    <button class="btn-block-primary" onclick="switchTab('home')">Back to Home</button>
  </div>

  <!-- SCREEN 5: REWARDS -->
  <div id="screen-rewards" class="screen-view">
    <div style="font-size:18px; font-weight:800; margin-bottom:14px;">Cashback & Rewards</div>

    <div style="background:linear-gradient(135deg, var(--primary), #6C5CE7); border-radius:20px; padding:18px; color:white; margin-bottom:16px;">
      <div style="font-size:11px; font-weight:700; opacity:0.85;">TOTAL REWARDS WON</div>
      <div style="font-size:32px; font-weight:800; margin:4px 0;">₹<span id="totalRewardsWon">60</span></div>
      <div style="font-size:12px; opacity:0.9;">Credited directly to your Volt Wallet</div>
    </div>

    <div style="font-weight:700; font-size:14px; margin-bottom:10px;">Available Scratch Cards</div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;" id="rewardsCardsGrid"></div>
  </div>

  <!-- SCREEN 6: TRANSACTIONS -->
  <div id="screen-transactions" class="screen-view">
    <div style="font-size:18px; font-weight:800; margin-bottom:12px;">Transaction History</div>
    <div id="transactionsList"></div>
  </div>

  <!-- SCREEN 7: UTILITY BILL DASHBOARD -->
  <div id="screen-utility" class="screen-view">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
      <div>
        <div style="font-weight:800; font-size:17px;">Utility Bill Payments</div>
        <div style="font-size:11px; color:var(--text-muted);">Electricity • Piped Gas • Water • LPG</div>
      </div>
      <button class="chip" onclick="switchTab('home')">Back</button>
    </div>

    <!-- Category selector tabs -->
    <div class="filter-chips" style="margin-bottom:14px;">
      <div class="chip active" id="utilTab-Electricity" onclick="selectUtilCat('Electricity', this)">⚡ Electricity</div>
      <div class="chip" id="utilTab-Gas" onclick="selectUtilCat('Piped Gas', this)">🔥 Piped Gas</div>
      <div class="chip" id="utilTab-Water" onclick="selectUtilCat('Water', this)">💧 Water</div>
      <div class="chip" id="utilTab-LPG" onclick="selectUtilCat('LPG Gas', this)">🛢️ LPG Gas</div>
    </div>

    <!-- Consumer ID Fetcher Card -->
    <div class="card">
      <div style="font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px;">Select Biller / Provider</div>
      <select id="utilProviderSelect" class="form-input" style="margin-bottom:12px; font-weight:700;" onchange="onUtilProviderChange()">
        <option value="Tata Power (Mumbai/Delhi)">Tata Power (Mumbai/Delhi)</option>
        <option value="BSES Rajdhani Power">BSES Rajdhani Power Limited</option>
        <option value="BESCOM (Bangalore)">BESCOM (Bangalore Electricity)</option>
        <option value="Mahavitaran (MSEDCL)">Mahavitaran (MSEDCL)</option>
      </select>

      <div style="font-size:12px; font-weight:700; color:var(--text-muted); margin-bottom:6px;" id="utilInputLabel">Consumer Account Number (CA Number)</div>
      <input type="text" id="utilConsumerInput" class="form-input" placeholder="e.g. 102938472" value="102938472" style="margin-bottom:8px;">

      <!-- Quick sample ID chips -->
      <div style="display:flex; gap:6px; align-items:center; margin-bottom:14px; font-size:11px;">
        <span style="color:var(--text-muted);">Sample:</span>
        <span class="chip" style="padding:2px 8px; font-size:11px;" onclick="setUtilSample('102938472')">102938472</span>
        <span class="chip" style="padding:2px 8px; font-size:11px;" onclick="setUtilSample('88392019')">88392019</span>
      </div>

      <button class="btn-block-primary" onclick="fetchDueBillWeb()" id="fetchBillBtn">
        <span>Fetch Due Bill</span>
      </button>
    </div>

    <!-- Fetched Bill Display Card -->
    <div id="fetchedBillCard" style="display:none; background:linear-gradient(135deg,#0F172A,#1E293B); color:white; border-radius:20px; padding:18px; margin-bottom:16px; border:1px solid var(--cyan);">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span style="background:rgba(0,200,83,0.2); color:var(--mint); font-size:10px; font-weight:800; padding:2px 8px; border-radius:4px;">VERIFIED BILL</span>
        <span style="font-size:12px; opacity:0.85;" id="fbProvider">Tata Power</span>
      </div>

      <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:12px;">
        <div>
          <div style="font-size:10px; font-weight:700; opacity:0.6;">AMOUNT DUE</div>
          <div style="font-size:28px; font-weight:800;" id="fbAmount">₹1,480</div>
        </div>
        <div style="background:rgba(255,159,28,0.25); color:var(--amber); font-size:11px; font-weight:700; padding:3px 8px; border-radius:6px;" id="fbDueDate">Due: 02 Oct 2026</div>
      </div>

      <div style="background:rgba(255,255,255,0.08); border-radius:12px; padding:10px; font-size:12px; margin-bottom:14px; line-height:1.6;">
        <div style="display:flex; justify-content:space-between;"><span style="opacity:0.7;">Consumer Name:</span><span style="font-weight:700;" id="fbName">Rahul Sharma</span></div>
        <div style="display:flex; justify-content:space-between;"><span style="opacity:0.7;">Consumer ID:</span><span style="font-weight:700;" id="fbCid">102938472</span></div>
        <div style="display:flex; justify-content:space-between;"><span style="opacity:0.7;">Billing Period:</span><span id="fbPeriod">Aug 2026 - Sep 2026</span></div>
        <div style="display:flex; justify-content:space-between;"><span style="opacity:0.7;">Consumption:</span><span style="color:var(--cyan); font-weight:700;" id="fbUnits">214 kWh Units</span></div>
      </div>

      <button class="btn-block-primary" onclick="payFetchedDueBill()" style="margin:0;">Pay Bill Now →</button>
    </div>

    <!-- BBPS Trust card -->
    <div style="background:rgba(0,200,83,0.08); border:1px solid rgba(0,200,83,0.25); border-radius:16px; padding:12px; display:flex; align-items:center; gap:10px;">
      <span style="font-size:22px;">🛡️</span>
      <div style="font-size:11px; color:var(--text);">
        <strong style="color:var(--mint);">Bharat BillPay (BBPS) Secured</strong><br>
        Instant electronic confirmation with official receipt and zero transaction fee.
      </div>
    </div>
  </div>

  <!-- BOTTOM NAV BAR -->
  <div class="bottom-nav">
    <div class="nav-item active" onclick="switchTab('home')" id="nav-home">
      <svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
      <span>Home</span>
    </div>
    <div class="nav-item" onclick="switchTab('plans')" id="nav-plans">
      <svg viewBox="0 0 24 24"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>
      <span>Plans</span>
    </div>
    <div class="nav-item" onclick="switchTab('rewards')" id="nav-rewards">
      <svg viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
      <span>Rewards</span>
    </div>
    <div class="nav-item" onclick="switchTab('transactions')" id="nav-transactions">
      <svg viewBox="0 0 24 24"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>
      <span>History</span>
    </div>
  </div>

  <!-- MODAL: ADD MONEY TO WALLET -->
  <div id="walletModal" class="modal-overlay" onclick="closeModals(event)">
    <div class="modal-sheet" onclick="event.stopPropagation()">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
        <div style="font-weight:800; font-size:16px;">Add Money to Volt Wallet</div>
        <span style="font-size:20px; cursor:pointer;" onclick="closeWalletModal()">✕</span>
      </div>
      <div style="font-size:12px; color:var(--text-muted); margin-bottom:6px;">Enter Amount</div>
      <input type="number" id="addMoneyInput" class="form-input" value="500" style="font-size:20px; font-weight:800; margin-bottom:12px;">
      <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-bottom:16px;">
        <div class="preset-chip" onclick="setAddMoney(100)">+₹100</div>
        <div class="preset-chip" onclick="setAddMoney(200)">+₹200</div>
        <div class="preset-chip" onclick="setAddMoney(500)">+₹500</div>
        <div class="preset-chip" onclick="setAddMoney(1000)">+₹1000</div>
      </div>
      <button class="btn-block-primary" onclick="confirmAddMoney()">Add to Wallet</button>
    </div>
  </div>

  <!-- MODAL: COUPON CODES -->
  <div id="couponModal" class="modal-overlay" onclick="closeModals(event)">
    <div class="modal-sheet" onclick="event.stopPropagation()">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
        <div style="font-weight:800; font-size:16px;">Apply Promo Code</div>
        <span style="font-size:20px; cursor:pointer;" onclick="closeCouponModal()">✕</span>
      </div>
      <div class="card" style="margin-bottom:10px; cursor:pointer;" onclick="applyPromo('VOLT50', 50, 299)">
        <div style="display:flex; justify-content:space-between;">
          <span style="font-weight:800; color:var(--primary);">VOLT50</span>
          <span style="font-size:11px; font-weight:700; color:var(--mint);">SAVE ₹50</span>
        </div>
        <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">Flat ₹50 off on recharges of ₹299 or more</div>
      </div>
      <div class="card" style="margin-bottom:10px; cursor:pointer;" onclick="applyPromo('SUPER10', 35, 199)">
        <div style="display:flex; justify-content:space-between;">
          <span style="font-weight:800; color:var(--primary);">SUPER10</span>
          <span style="font-size:11px; font-weight:700; color:var(--mint);">10% OFF</span>
        </div>
        <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">Save 10% up to ₹40 on prepaid recharges</div>
      </div>
    </div>
  </div>

  <!-- MODAL: INTERACTIVE SCRATCH CARD -->
  <div id="scratchModal" class="modal-overlay" onclick="closeModals(event)">
    <div class="modal-sheet" onclick="event.stopPropagation()" style="text-align:center;">
      <div style="font-size:18px; font-weight:800; margin-bottom:4px;">Scratch & Win!</div>
      <div style="font-size:12px; color:var(--text-muted);">Swipe across the card to reveal mystery cashback</div>
      <div class="scratch-box">
        <span style="font-size:36px;">🎉</span>
        <div style="font-size:12px; font-weight:700; color:#64748B;">You Won</div>
        <div style="font-size:36px; font-weight:800; color:var(--mint);" id="scratchAmountDisplay">₹25</div>
        <div style="font-size:11px; font-weight:700; color:var(--primary);">Volt Wallet Cashback</div>
        <canvas id="scratchCanvas" width="220" height="220"></canvas>
      </div>
      <button class="btn-block-primary" onclick="claimScratchReward()">Claim Cashback</button>
    </div>
  </div>

  <!-- MODAL: PAYMENT PROCESSING ANIMATION -->
  <div id="processingModal" class="modal-overlay">
    <div class="modal-sheet" style="text-align:center; padding:30px;">
      <div style="font-size:40px; margin-bottom:14px; animation:spin 1.5s linear infinite; display:inline-block;">⚡</div>
      <div style="font-size:18px; font-weight:800; margin-bottom:6px;">Connecting to Operator</div>
      <div style="font-size:13px; color:var(--text-muted);" id="procStatusText">Verifying payment & activating 5G benefits...</div>
    </div>
  </div>
</div>

<script>
  let walletBalance = 450.00;
  let currentTargetNum = '9876543210';
  let currentOperator = 'Jio';
  let currentCircle = 'Delhi NCR';
  let selectedPlan = {
    id: 'jio_349',
    amount: 349,
    validity: '28 Days',
    data: '2 GB/day',
    desc: 'Unlimited 5G Data included + JioCinema, JioTV and JioCloud subscriptions.',
    is5G: true
  };
  let appliedDiscount = 0;
  let appliedCouponCode = '';

  const plansData = [
    { id: 'jio_349', amount: 349, validity: '28 Days', data: '2 GB/day', category: 'POPULAR', desc: 'Unlimited True 5G data + JioCinema & JioTV subscriptions.', is5G: true, popular: true, ott: 'JioCinema' },
    { id: 'jio_299', amount: 299, validity: '28 Days', data: '1.5 GB/day', category: 'DAILY', desc: 'Standard daily 1.5GB/day pack with unlimited calls.', is5G: false, popular: false, ott: 'JioTV' },
    { id: 'jio_449', amount: 449, validity: '28 Days', data: '3 GB/day', category: 'OTT', desc: 'Disney+ Hotstar 3 Months Mobile included with True 5G.', is5G: true, popular: true, ott: 'Disney+ Hotstar' },
    { id: 'jio_899', amount: 899, validity: '90 Days', data: '2 GB/day', category: 'POPULAR', desc: 'Quarterly plan: 20GB extra data + Unlimited 5G for 90 days.', is5G: true, popular: true, ott: 'JioCinema' },
    { id: 'jio_1029', amount: 1029, validity: '84 Days', data: '2 GB/day', category: 'OTT', desc: 'Amazon Prime Lite (84 days) + Unlimited 5G Data included.', is5G: true, popular: false, ott: 'Amazon Prime Lite' },
    { id: 'jio_3599', amount: 3599, validity: '365 Days', data: '2.5 GB/day', category: 'ANNUAL', desc: 'Full Year Peace of Mind: 912.5GB Data + Unlimited 5G.', is5G: true, popular: true, ott: 'JioCinema' },
    { id: 'jio_61', amount: 61, validity: 'Existing Plan', data: '6 GB Bulk', category: 'BOOSTER', desc: '5G Upgrade voucher + 6GB high speed data.', is5G: true, popular: false, ott: '' }
  ];

  let scratchCards = [
    { id: 1, amount: 25, isScratched: false },
    { id: 2, amount: 35, isScratched: true }
  ];

  let transactions = [
    { id: 'VC-90482183', num: '9876543210', op: 'Jio', amt: 349, status: 'SUCCESS', date: 'Today, 02:15 PM' },
    { id: 'VC-89210944', num: '9810012345', op: 'Airtel', amt: 859, status: 'SUCCESS', date: 'Yesterday' }
  ];

  function switchTab(tab) {
    document.querySelectorAll('.screen-view').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    
    const screen = document.getElementById('screen-' + tab);
    if (screen) screen.classList.add('active');
    
    const nav = document.getElementById('nav-' + tab);
    if (nav) nav.classList.add('active');

    if (tab === 'plans') renderPlans();
    if (tab === 'rewards') renderRewards();
    if (tab === 'transactions') renderTransactions();
  }

  function goToPlansFromHome() {
    const input = document.getElementById('homeMobileInput').value.trim();
    if (input.length === 10) {
      currentTargetNum = input;
      document.getElementById('planHeaderNumber').innerText = currentTargetNum;
      switchTab('plans');
    } else {
      alert('Please enter a valid 10-digit mobile number');
    }
  }

  function quickRechargePrimary() {
    currentTargetNum = '9876543210';
    choosePlan(plansData[0]);
  }

  function repeatBeneficiary(num, op, amt) {
    currentTargetNum = num;
    currentOperator = op;
    const plan = plansData.find(p => p.amount === amt) || plansData[0];
    choosePlan(plan);
  }

  function openService(serviceName) {
    currentTargetNum = prompt('Enter ' + serviceName + ' Number / ID:', '9876543210') || '9876543210';
    document.getElementById('planHeaderNumber').innerText = currentTargetNum;
    switchTab('plans');
  }

  let currentDataFilter = 'ALL';
  let currentValFilter = 'ALL';
  let currentPriceFilter = 'ALL';

  function renderPlans() {
    const container = document.getElementById('plansList');
    container.innerHTML = '';
    const search = (document.getElementById('planSearchInput').value || '').toLowerCase().trim();
    
    const filtered = plansData.filter(p => {
      // Search
      const matchSearch = search === '' || 
        p.amount.toString().includes(search) || 
        p.data.toLowerCase().includes(search) || 
        p.desc.toLowerCase().includes(search) ||
        p.validity.toLowerCase().includes(search);

      // Data
      let matchData = true;
      if (currentDataFilter === '1.5') matchData = p.data.includes('1.5');
      else if (currentDataFilter === '2') matchData = p.data.includes('2 GB');
      else if (currentDataFilter === '5G') matchData = p.is5G;

      // Validity
      let matchVal = true;
      if (currentValFilter === '28') matchVal = p.validity.includes('28');
      else if (currentValFilter === '84') matchVal = p.validity.includes('84') || p.validity.includes('90');
      else if (currentValFilter === '365') matchVal = p.validity.includes('365');

      // Price
      let matchPrice = true;
      if (currentPriceFilter === 'MID') matchPrice = p.amount >= 200 && p.amount <= 500;
      else if (currentPriceFilter === 'HIGH') matchPrice = p.amount > 500;

      return matchSearch && matchData && matchVal && matchPrice;
    });

    if (filtered.length === 0) {
      container.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-muted);"><div style="font-size:32px; margin-bottom:8px;">🔍</div><strong>No recharge plans found</strong><p style="font-size:12px; margin-top:4px;">Try changing or resetting your filters.</p></div>';
      return;
    }

    filtered.forEach(p => {
      const card = document.createElement('div');
      card.className = 'plan-card';
      card.innerHTML = \`
        <div class="plan-price-row">
          <div>
            <span class="price-lg">₹\${p.amount}</span>
            <span class="per-day">₹\${(p.amount / parseInt(p.validity) || 12).toFixed(1)}/d</span>
          </div>
          <div style="display:flex; gap:6px;">
            \${p.is5G ? '<span style="background:linear-gradient(135deg,#0D53FC,#00C6FF); color:white; font-size:10px; font-weight:800; padding:2px 6px; border-radius:6px;">⚡ Unlimited 5G</span>' : ''}
            \${p.popular ? '<span style="background:rgba(255,159,28,0.2); color:var(--amber); font-size:10px; font-weight:800; padding:2px 6px; border-radius:6px;">POPULAR</span>' : ''}
          </div>
        </div>
        <div class="plan-specs">
          <div class="spec-item"><span class="spec-title">VALIDITY</span><span class="spec-val">\${p.validity}</span></div>
          <div class="spec-item"><span class="spec-title">DATA</span><span class="spec-val">\${p.data}</span></div>
          <div class="spec-item"><span class="spec-title">CALLS</span><span class="spec-val">Unlimited</span></div>
        </div>
        <div style="font-size:12px; color:var(--text-muted); margin-bottom:12px;">\${p.desc}</div>
        <div style="display:flex; gap:8px;">
          <button class="btn-sm-primary" style="background:rgba(13,83,252,0.1); color:var(--primary); border:1px solid rgba(13,83,252,0.3); flex:1; padding:10px;" onclick="choosePlanById('\${p.id}')">⚡ Quick Pay</button>
          <button class="btn-sm-primary" style="flex:1.2; padding:10px;" onclick="choosePlanById('\${p.id}')">Recharge ₹\${p.amount}</button>
        </div>
      \`;
      container.appendChild(card);
    });
  }

  function setDataFilter(val, el) {
    currentDataFilter = val;
    document.querySelectorAll('[id^="chip-data-"]').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    renderPlans();
  }

  function setValFilter(val, el) {
    currentValFilter = val;
    document.querySelectorAll('[id^="chip-val-"]').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    renderPlans();
  }

  function setPriceFilter(val, el) {
    currentPriceFilter = val;
    document.querySelectorAll('[id^="chip-price-"]').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    renderPlans();
  }

  function resetPlanFilters() {
    currentDataFilter = 'ALL';
    currentValFilter = 'ALL';
    currentPriceFilter = 'ALL';
    document.getElementById('planSearchInput').value = '';
    document.querySelectorAll('[id^="chip-data-"], [id^="chip-val-"], [id^="chip-price-"]').forEach(c => c.classList.remove('active'));
    document.getElementById('chip-data-ALL').classList.add('active');
    document.getElementById('chip-val-ALL').classList.add('active');
    renderPlans();
  }

  function filterPlans() {
    renderPlans();
  }

  function choosePlanById(id) {
    const p = plansData.find(x => x.id === id);
    if (p) choosePlan(p);
  }

  function choosePlan(p) {
    selectedPlan = p;
    document.getElementById('checkoutTargetNum').innerText = currentTargetNum;
    document.getElementById('checkoutOpInfo').innerText = currentOperator + ' • ' + currentCircle + ' Prepaid';
    document.getElementById('checkoutBaseAmount').innerText = '₹' + p.amount;
    document.getElementById('checkoutPlanDesc').innerText = p.desc;
    document.getElementById('checkoutValidity').innerText = '⏳ ' + p.validity;
    document.getElementById('checkoutData').innerText = '📶 ' + p.data;
    document.getElementById('billPackAmt').innerText = '₹' + p.amount;
    appliedDiscount = 0;
    document.getElementById('walletCheckbox').checked = false;
    updateCheckoutTotal();
    switchTab('checkout');
  }

  function updateCheckoutTotal() {
    const base = selectedPlan.amount;
    let net = Math.max(0, base - appliedDiscount);

    if (appliedDiscount > 0) {
      document.getElementById('billCouponRow').style.display = 'flex';
      document.getElementById('billCouponAmt').innerText = '-₹' + appliedDiscount;
    } else {
      document.getElementById('billCouponRow').style.display = 'none';
    }

    const useWallet = document.getElementById('walletCheckbox').checked;
    let walletUsed = 0;
    if (useWallet) {
      walletUsed = Math.min(walletBalance, net);
      document.getElementById('billWalletRow').style.display = 'flex';
      document.getElementById('billWalletAmt').innerText = '-₹' + walletUsed;
    } else {
      document.getElementById('billWalletRow').style.display = 'none';
    }

    const payable = Math.max(0, net - walletUsed);
    document.getElementById('billFinalPayable').innerText = '₹' + payable;
    document.getElementById('payBtn').innerText = payable > 0 ? ('Proceed to Pay ₹' + payable) : 'Confirm Recharge';
  }

  function startPaymentProcess() {
    document.getElementById('processingModal').classList.add('active');
    setTimeout(() => {
      document.getElementById('procStatusText').innerText = 'Authorizing payment with bank...';
    }, 800);
    setTimeout(() => {
      document.getElementById('procStatusText').innerText = 'Activating plan benefits on telecom network...';
    }, 1600);
    setTimeout(() => {
      document.getElementById('processingModal').classList.remove('active');
      completeRecharge();
    }, 2400);
  }

  function completeRecharge() {
    const useWallet = document.getElementById('walletCheckbox').checked;
    const base = selectedPlan.amount;
    const net = Math.max(0, base - appliedDiscount);
    const walletUsed = useWallet ? Math.min(walletBalance, net) : 0;
    
    if (walletUsed > 0) {
      walletBalance -= walletUsed;
      updateWalletDisplay();
    }

    // Add new scratch card
    scratchCards.unshift({ id: Date.now(), amount: 30, isScratched: false });

    // Add to transactions
    transactions.unshift({
      id: 'VC-' + Math.floor(10000000 + Math.random() * 90000000),
      num: currentTargetNum,
      op: currentOperator,
      amt: selectedPlan.amount,
      status: 'SUCCESS',
      date: 'Just now'
    });

    document.getElementById('successAmtDisplay').innerText = '₹' + selectedPlan.amount;
    document.getElementById('successSubDisplay').innerText = currentOperator + ' • ' + currentTargetNum;
    document.getElementById('successValidity').innerText = selectedPlan.validity;
    document.getElementById('successTxnId').innerText = transactions[0].id;
    document.getElementById('successRefId').innerText = currentOperator.toUpperCase() + '-' + Math.floor(100000 + Math.random() * 900000);

    switchTab('success');
  }

  function renderRewards() {
    const grid = document.getElementById('rewardsCardsGrid');
    grid.innerHTML = '';
    const totalWon = scratchCards.filter(c => c.isScratched).reduce((a, b) => a + b.amount, 0);
    document.getElementById('totalRewardsWon').innerText = totalWon;

    scratchCards.forEach(c => {
      const box = document.createElement('div');
      box.style.cssText = 'height:130px; border-radius:18px; padding:12px; display:flex; flex-direction:column; align-items:center; justify-content:center; cursor:pointer; text-align:center; ' + 
        (c.isScratched ? 'background:white; border:1px solid var(--border);' : 'background:linear-gradient(135deg, #2B3A67, #1E2846); color:white; border:1px solid var(--amber);');
      
      if (c.isScratched) {
        box.innerHTML = \`<span style="font-size:24px;">🎉</span><span style="font-weight:800; font-size:16px; color:var(--mint); margin:4px 0;">Won ₹\${c.amount}</span><span style="font-size:10px; color:var(--text-muted);">Added to Wallet</span>\`;
      } else {
        box.innerHTML = \`<span style="font-size:24px;">🎁</span><span style="font-weight:700; font-size:13px; margin:4px 0;">Tap to Scratch</span><span style="font-size:10px; color:var(--amber);">Win up to ₹100</span>\`;
        box.onclick = () => openScratchModal(c);
      }
      grid.appendChild(box);
    });
  }

  let activeScratchCard = null;
  function openScratchModal(card) {
    activeScratchCard = card;
    document.getElementById('scratchAmountDisplay').innerText = '₹' + card.amount;
    document.getElementById('scratchModal').classList.add('active');
    initScratchCanvas();
  }

  function initScratchCanvas() {
    const canvas = document.getElementById('scratchCanvas');
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#2B3A67';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.font = 'bold 14px sans-serif';
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.fillText('Rub to Scratch', 110, 110);

    let isDrawing = false;
    let clearedCount = 0;

    function scratch(e) {
      if (!isDrawing) return;
      const rect = canvas.getBoundingClientRect();
      const x = (e.clientX || e.touches[0].clientX) - rect.left;
      const y = (e.clientY || e.touches[0].clientY) - rect.top;
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(x, y, 24, 0, Math.PI * 2);
      ctx.fill();
      clearedCount++;
      if (clearedCount > 18) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    }

    canvas.onmousedown = () => isDrawing = true;
    canvas.onmouseup = () => isDrawing = false;
    canvas.onmousemove = scratch;
    canvas.ontouchstart = () => isDrawing = true;
    canvas.ontouchend = () => isDrawing = false;
    canvas.ontouchmove = scratch;
  }

  function claimScratchReward() {
    if (activeScratchCard && !activeScratchCard.isScratched) {
      activeScratchCard.isScratched = true;
      walletBalance += activeScratchCard.amount;
      updateWalletDisplay();
    }
    document.getElementById('scratchModal').classList.remove('active');
    renderRewards();
  }

  function renderTransactions() {
    const list = document.getElementById('transactionsList');
    list.innerHTML = '';
    transactions.forEach(t => {
      const row = document.createElement('div');
      row.className = 'card';
      row.style.marginBottom = '10px';
      row.innerHTML = \`
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div style="display:flex; align-items:center; gap:10px;">
            <div style="width:36px; height:36px; border-radius:50%; background:rgba(13,83,252,0.1); color:var(--primary); font-weight:800; display:flex; align-items:center; justify-content:center; font-size:10px;">\${t.op}</div>
            <div>
              <div style="font-weight:700; font-size:13px;">\${t.op} • \${t.num}</div>
              <div style="font-size:11px; color:var(--text-muted);">\${t.date} • \${t.id}</div>
            </div>
          </div>
          <div style="text-align:right;">
            <div style="font-weight:800; font-size:15px;">₹\${t.amt}</div>
            <span style="font-size:10px; font-weight:700; color:var(--mint); background:rgba(0,200,83,0.12); padding:2px 6px; border-radius:4px;">SUCCESS</span>
          </div>
        </div>
      \`;
      list.appendChild(row);
    });
  }

  function openWalletModal() {
    document.getElementById('walletModal').classList.add('active');
  }
  function closeWalletModal() {
    document.getElementById('walletModal').classList.remove('active');
  }
  function setAddMoney(amt) {
    document.getElementById('addMoneyInput').value = amt;
  }
  function confirmAddMoney() {
    const amt = parseFloat(document.getElementById('addMoneyInput').value) || 0;
    if (amt > 0) {
      walletBalance += amt;
      updateWalletDisplay();
      closeWalletModal();
      alert('₹' + amt + ' added to Volt Wallet successfully!');
    }
  }

  function updateWalletDisplay() {
    document.getElementById('walletBalanceTop').innerText = walletBalance.toFixed(2);
    document.getElementById('checkoutWalletBal').innerText = walletBalance.toFixed(2);
  }

  function openCouponModal() {
    document.getElementById('couponModal').classList.add('active');
  }
  function closeCouponModal() {
    document.getElementById('couponModal').classList.remove('active');
  }
  function applyPromo(code, disc, min) {
    if (selectedPlan.amount >= min) {
      appliedDiscount = disc;
      appliedCouponCode = code;
      document.getElementById('appliedCouponTitle').innerText = 'Coupon ' + code + ' Applied';
      document.getElementById('appliedCouponSub').innerText = 'You save ₹' + disc;
      closeCouponModal();
      updateCheckoutTotal();
    } else {
      alert('Minimum recharge of ₹' + min + ' required for this coupon');
    }
  }

  function switchOperator() {
    const newOp = prompt('Switch Operator (Jio, Airtel, Vi, BSNL):', currentOperator);
    if (newOp) {
      currentOperator = newOp;
      document.getElementById('planHeaderOperator').innerText = currentOperator;
    }
  }

  let activeUtilCategory = 'Electricity';
  let fetchedBillData = null;

  const utilProviders = {
    'Electricity': ['Tata Power (Mumbai/Delhi)', 'BSES Rajdhani Power', 'BESCOM (Bangalore)', 'Mahavitaran (MSEDCL)', 'UPPCL (Urban / Rural)'],
    'Piped Gas': ['Indraprastha Gas Limited (IGL)', 'Mahanagar Gas Limited (MGL)', 'Adani Total Gas', 'Gujarat Gas Limited'],
    'Water': ['Delhi Jal Board (DJB)', 'Bangalore Water Supply (BWSSB)', 'MCGM Water (Mumbai)', 'Hyderabad Water Board (HMWSSB)'],
    'LPG Gas': ['Indane Gas (Indian Oil)', 'Bharat Gas (BPCL)', 'HP Gas (HPCL)']
  };

  const sampleBillsData = {
    'Electricity': { name: 'Rahul Sharma', amount: 1480, dueDate: '02 Oct 2026', units: '214 kWh Units', cid: '102938472' },
    'Piped Gas': { name: 'Priya Verma', amount: 620, dueDate: '28 Sep 2026', units: '28 SCM Units', cid: '88392019' },
    'Water': { name: 'Vikram Patel', amount: 340, dueDate: '26 Sep 2026', units: '18 Kilolitres', cid: '55201938' },
    'LPG Gas': { name: 'Anjali Gupta', amount: 925, dueDate: 'Refill Booking', units: '14.2 kg Cylinder', cid: '9876543210' }
  };

  function openUtilityDashboard(category) {
    selectUtilCat(category);
    switchTab('utility');
  }

  function selectUtilCat(cat, el) {
    activeUtilCategory = cat;
    document.querySelectorAll('#screen-utility .filter-chips .chip').forEach(c => c.classList.remove('active'));
    if (el) el.classList.add('active');
    else {
      const targetChip = document.getElementById('utilTab-' + (cat.includes('Gas') ? 'Gas' : cat.includes('LPG') ? 'LPG' : cat));
      if (targetChip) targetChip.classList.add('active');
    }

    // Populate providers
    const select = document.getElementById('utilProviderSelect');
    select.innerHTML = '';
    const providers = utilProviders[cat] || utilProviders['Electricity'];
    providers.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p;
      opt.innerText = p;
      select.appendChild(opt);
    });

    // Update label & sample ID
    const label = document.getElementById('utilInputLabel');
    const input = document.getElementById('utilConsumerInput');
    const sample = sampleBillsData[cat] || sampleBillsData['Electricity'];

    if (cat === 'Electricity') label.innerText = 'Consumer Account Number (CA Number)';
    else if (cat === 'Piped Gas') label.innerText = 'BP Number / Customer ID';
    else if (cat === 'Water') label.innerText = 'Consumer / K-Number';
    else if (cat === 'LPG Gas') label.innerText = '17-digit LPG ID or Registered Mobile';

    input.value = sample.cid;
    document.getElementById('fetchedBillCard').style.display = 'none';
  }

  function setUtilSample(id) {
    document.getElementById('utilConsumerInput').value = id;
  }

  function fetchDueBillWeb() {
    const cid = document.getElementById('utilConsumerInput').value.trim();
    if (!cid) {
      alert('Please enter a valid Consumer ID');
      return;
    }

    const btn = document.getElementById('fetchBillBtn');
    btn.innerHTML = '<span>⚡ Fetching from Biller...</span>';
    btn.disabled = true;

    setTimeout(() => {
      btn.innerHTML = '<span>Fetch Due Bill</span>';
      btn.disabled = false;

      const provider = document.getElementById('utilProviderSelect').value;
      const sample = sampleBillsData[activeUtilCategory] || sampleBillsData['Electricity'];

      fetchedBillData = {
        name: sample.name,
        amount: sample.amount,
        dueDate: sample.dueDate,
        units: sample.units,
        provider: provider,
        cid: cid
      };

      document.getElementById('fbProvider').innerText = provider;
      document.getElementById('fbAmount').innerText = '₹' + sample.amount;
      document.getElementById('fbDueDate').innerText = 'Due: ' + sample.dueDate;
      document.getElementById('fbName').innerText = sample.name;
      document.getElementById('fbCid').innerText = cid;
      document.getElementById('fbUnits').innerText = sample.units;

      document.getElementById('fetchedBillCard').style.display = 'block';
    }, 700);
  }

  function payFetchedDueBill() {
    if (!fetchedBillData) return;
    currentTargetNum = fetchedBillData.cid;
    currentOperator = fetchedBillData.provider;
    selectedPlan = {
      id: 'bill_' + Date.now(),
      amount: fetchedBillData.amount,
      validity: 'Bill Payment',
      data: fetchedBillData.units,
      desc: activeUtilCategory + ' bill payment for ' + fetchedBillData.name + ' (' + fetchedBillData.cid + ')'
    };

    document.getElementById('checkoutTargetNum').innerText = fetchedBillData.cid;
    document.getElementById('checkoutOpInfo').innerText = fetchedBillData.provider + ' (' + activeUtilCategory + ')';
    document.getElementById('checkoutBaseAmount').innerText = '₹' + fetchedBillData.amount;
    document.getElementById('checkoutPlanDesc').innerText = selectedPlan.desc;
    document.getElementById('checkoutValidity').innerText = '📅 ' + fetchedBillData.dueDate;
    document.getElementById('checkoutData').innerText = '⚡ ' + fetchedBillData.units;
    document.getElementById('billPackAmt').innerText = '₹' + fetchedBillData.amount;
    appliedDiscount = 0;
    document.getElementById('walletCheckbox').checked = false;
    updateCheckoutTotal();
    switchTab('checkout');
  }

  function closeModals(e) {
    if (e.target.classList.contains('modal-overlay')) {
      e.target.classList.remove('active');
    }
  }
</script>
</body>
</html>
`;

const server = http.createServer((req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-cache, no-store, must-revalidate'
  });
  res.end(HTML_CONTENT);
});

server.listen(PORT, () => {
  console.log(`VoltCharge web preview running on http://localhost:${PORT}`);
});
