package com.example

import com.example.recharge.data.SampleData
import com.example.recharge.model.PlanCategory
import com.example.recharge.model.ServiceType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RechargeAppUnitTest {

    @Test
    fun testSampleOperatorsAvailability() {
        val mobileOperators = SampleData.OPERATORS.filter { it.serviceType == ServiceType.MOBILE_PREPAID }
        assertTrue(mobileOperators.isNotEmpty())
        assertTrue(mobileOperators.any { it.name == "Jio" })
        assertTrue(mobileOperators.any { it.name == "Airtel" })
        assertTrue(mobileOperators.any { it.name == "Vi" })
        assertTrue(mobileOperators.any { it.name == "BSNL" })
    }

    @Test
    fun testRechargePlansPerDayCalculation() {
        val plan = SampleData.ALL_PLANS.first { it.id == "jio_349" }
        assertEquals(349.0, plan.amount, 0.01)
        assertEquals("28 Days", plan.validity)
        assertEquals("2 GB/day", plan.dataAllowance)
        assertTrue(plan.is5GUnlimited)
        assertEquals("₹12.5/day", plan.perDayPrice)
    }

    @Test
    fun testPromoCodeDiscountCalculation() {
        val promo = SampleData.PROMO_CODES.first { it.code == "VOLT50" }
        assertEquals(50.0, promo.discountAmount, 0.01)
        assertEquals(299.0, promo.minAmount, 0.01)
        assertTrue(349.0 >= promo.minAmount)
    }

    @Test
    fun testPopularPlanCategories() {
        val popularPlans = SampleData.ALL_PLANS.filter { it.category == PlanCategory.POPULAR }
        assertTrue(popularPlans.isNotEmpty())
        assertTrue(popularPlans.all { it.category == PlanCategory.POPULAR })
    }

    @Test
    fun testUtilityBillProvidersAndSamples() {
        val electricityProviders = SampleData.OPERATORS.filter { it.serviceType == ServiceType.ELECTRICITY }
        val gasProviders = SampleData.OPERATORS.filter { it.serviceType == ServiceType.GAS }
        val waterProviders = SampleData.OPERATORS.filter { it.serviceType == ServiceType.WATER }

        assertTrue(electricityProviders.isNotEmpty())
        assertTrue(gasProviders.isNotEmpty())
        assertTrue(waterProviders.isNotEmpty())

        assertTrue(SampleData.SAMPLE_BILLS.any { it.serviceType == ServiceType.ELECTRICITY })
        assertTrue(SampleData.SAMPLE_BILLS.any { it.serviceType == ServiceType.GAS })
        assertTrue(SampleData.SAMPLE_BILLS.any { it.serviceType == ServiceType.WATER })

        val elecBill = SampleData.SAMPLE_BILLS.first { it.serviceType == ServiceType.ELECTRICITY }
        assertEquals("102938472", elecBill.consumerId)
        assertTrue(elecBill.amountDue > 0)
    }

    @Test
    fun testPlanFilteringByDataValidityAndPrice() {
        val jioPlans = SampleData.ALL_PLANS.filter { it.operatorId == "jio" }
        assertTrue(jioPlans.isNotEmpty())

        // Filter by 2 GB/day data
        val twoGbPlans = jioPlans.filter { it.dataAllowance.startsWith("2 GB") }
        assertTrue(twoGbPlans.isNotEmpty())
        assertTrue(twoGbPlans.any { it.amount == 349.0 })

        // Filter by 28 Days validity
        val validity28Plans = jioPlans.filter { it.validity.contains("28") }
        assertTrue(validity28Plans.isNotEmpty())

        // Filter by Price bracket (< 500)
        val under500Plans = jioPlans.filter { it.amount in 200.0..500.0 }
        assertTrue(under500Plans.isNotEmpty())
        assertTrue(under500Plans.all { it.amount in 200.0..500.0 })

        // Filter by 5G Unlimited
        val unlimited5GPlans = jioPlans.filter { it.is5GUnlimited }
        assertTrue(unlimited5GPlans.isNotEmpty())
    }
}
