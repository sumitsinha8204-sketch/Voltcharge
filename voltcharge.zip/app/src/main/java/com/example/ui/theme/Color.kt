package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Brand Palette
val BrandBlue = Color(0xFF0D53FC)
val BrandBlueDark = Color(0xFF083BB5)
val BrandCyan = Color(0xFF00C6FF)
val BrandPurple = Color(0xFF6C5CE7)
val BrandMint = Color(0xFF00C853)
val BrandAmber = Color(0xFFFF9F1C)
val BrandCoral = Color(0xFFFF4757)

// Light Background & Surface
val LightBackground = Color(0xFFF6F8FD)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F9)
val LightOutline = Color(0xFFD8E2EE)
val LightOnSurface = Color(0xFF131A29)
val LightOnSurfaceVariant = Color(0xFF616F89)

// Dark Brand Palette
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111726)
val DarkSurfaceVariant = Color(0xFF1B2338)
val DarkOutline = Color(0xFF2B3752)
val DarkPrimary = Color(0xFF4D88FF)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

// Status & Operators Colors
val JioBlue = Color(0xFF0A2885)
val AirtelRed = Color(0xFFEE1C25)
val ViYellow = Color(0xFFFFC20E)
val BsnlOrange = Color(0xFFFF6A00)
val TataSkyBlue = Color(0xFFE50914)
