package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.recharge.ui.CheckoutScreen
import com.example.recharge.ui.DthFastagBillScreen
import com.example.recharge.ui.HomeScreen
import com.example.recharge.ui.PlanBrowser
import com.example.recharge.ui.PlanSelectionScreen
import com.example.recharge.ui.RewardsScreen
import com.example.recharge.ui.SuccessReceiptScreen
import com.example.recharge.ui.TransactionsScreen
import com.example.recharge.ui.UtilityBillDashboard
import com.example.recharge.viewmodel.RechargeViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RechargeAppNav()
                }
            }
        }
    }
}

@Composable
fun RechargeAppNav(viewModel: RechargeViewModel = viewModel()) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToPlans = { navController.navigate("plans") },
                onNavigateToUtility = { service ->
                    viewModel.selectService(service)
                    navController.navigate("utility")
                },
                onNavigateToUtilityBills = {
                    navController.navigate("utility_dashboard")
                },
                onNavigateToRewards = { navController.navigate("rewards") },
                onNavigateToTransactions = { navController.navigate("transactions") },
                onNavigateToCheckout = { navController.navigate("checkout") }
            )
        }

        composable("utility_dashboard") {
            UtilityBillDashboard(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onProceedToCheckout = { navController.navigate("checkout") }
            )
        }

        composable("plans") {
            PlanBrowser(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onProceedToCheckout = { navController.navigate("checkout") }
            )
        }

        composable("plan_browser") {
            PlanBrowser(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onProceedToCheckout = { navController.navigate("checkout") }
            )
        }

        composable("utility") {
            DthFastagBillScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onProceedToCheckout = { navController.navigate("checkout") }
            )
        }

        composable("checkout") {
            CheckoutScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onPaymentSuccess = {
                    navController.navigate("success") {
                        popUpTo("home") { inclusive = false }
                    }
                }
            )
        }

        composable("success") {
            SuccessReceiptScreen(
                viewModel = viewModel,
                onHome = {
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }
                },
                onViewRewards = { navController.navigate("rewards") }
            )
        }

        composable("rewards") {
            RewardsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("transactions") {
            TransactionsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
