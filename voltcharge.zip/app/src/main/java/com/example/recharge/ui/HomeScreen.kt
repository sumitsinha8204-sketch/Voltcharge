package com.example.recharge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.recharge.data.entity.SavedBeneficiary
import com.example.recharge.model.ServiceType
import com.example.recharge.ui.components.MobileRechargeCard
import com.example.recharge.ui.components.OperatorBadge
import com.example.recharge.ui.components.ServiceIcon
import com.example.recharge.ui.components.StatusPill
import com.example.recharge.viewmodel.RechargeViewModel
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandMint
import com.example.ui.theme.BrandPurple

@Composable
fun HomeScreen(
    viewModel: RechargeViewModel,
    onNavigateToPlans: () -> Unit,
    onNavigateToUtility: (ServiceType) -> Unit,
    onNavigateToUtilityBills: () -> Unit,
    onNavigateToRewards: () -> Unit,
    onNavigateToTransactions: () -> Unit,
    onNavigateToCheckout: () -> Unit
) {
    val walletBalance by viewModel.walletBalance.collectAsStateWithLifecycle()
    val beneficiaries by viewModel.beneficiaries.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val scratchCards by viewModel.scratchCards.collectAsStateWithLifecycle()
    val showWalletSheet by viewModel.showWalletSheet.collectAsStateWithLifecycle()
    val selectedOperator by viewModel.selectedOperator.collectAsStateWithLifecycle()
    val selectedCircle by viewModel.selectedCircle.collectAsStateWithLifecycle()
    val customAmount by viewModel.customAmount.collectAsStateWithLifecycle()
    val targetNumber by viewModel.targetNumber.collectAsStateWithLifecycle()

    val unscratchedCount = scratchCards.count { !it.isScratched }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Logo
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(listOf(BrandBlue, BrandCyan))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "VoltCharge Logo",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Text(
                        text = "VoltCharge",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Wallet Pill & Action Icons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Wallet Balance Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(100.dp))
                            .background(BrandBlue.copy(alpha = 0.1f))
                            .clickable { viewModel.setShowWalletSheet(true) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("wallet_balance_pill")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = BrandBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "₹${walletBalance.toInt()}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandBlue
                            )
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                tint = BrandBlue,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    // Rewards Icon with badge
                    Box {
                        IconButton(
                            onClick = onNavigateToRewards,
                            modifier = Modifier.testTag("rewards_icon_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stars,
                                contentDescription = "Rewards",
                                tint = BrandAmber
                            )
                        }
                        if (unscratchedCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 4.dp, end = 4.dp)
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(BrandMint),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = unscratchedCount.toString(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Transaction History Icon
                    IconButton(
                        onClick = onNavigateToTransactions,
                        modifier = Modifier.testTag("history_icon_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Active Current Plan Alert Card
            ActivePlanStatusCard(
                onRechargeAhead = {
                    val beneficiary = beneficiaries.firstOrNull()
                    if (beneficiary != null) {
                        viewModel.repeatRecharge(beneficiary) {
                            onNavigateToPlans()
                        }
                    } else {
                        viewModel.setTargetNumber("9876543210")
                        onNavigateToPlans()
                    }
                }
            )

            // Reusable Mobile Recharge Card Component
            MobileRechargeCard(
                phoneNumber = targetNumber,
                onPhoneNumberChange = { viewModel.setTargetNumber(it) },
                selectedOperator = selectedOperator,
                onOperatorChange = { viewModel.setOperator(it) },
                selectedCircle = selectedCircle,
                onCircleChange = { viewModel.setCircle(it) },
                amount = customAmount,
                onAmountChange = { viewModel.setCustomAmount(it) },
                onBrowsePlansClick = {
                    viewModel.selectService(ServiceType.MOBILE_PREPAID)
                    onNavigateToPlans()
                },
                onProceedClick = {
                    viewModel.selectService(ServiceType.MOBILE_PREPAID)
                    val amt = customAmount.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onNavigateToCheckout()
                    } else {
                        onNavigateToPlans()
                    }
                },
                availableOperators = viewModel.getOperatorsForCurrentService(),
                availableCircles = viewModel.getAvailableCircles()
            )

            // Utility Bills & Due Fetcher Hero Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF0F172A), Color(0xFF1E3A8A))
                        )
                    )
                    .border(1.dp, BrandBlue.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                    .clickable { onNavigateToUtilityBills() }
                    .padding(18.dp)
                    .testTag("utility_bills_hub_banner")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFF00C6FF)))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Utility Bills Hub",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(BrandMint)
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text("BBPS", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Electricity • Gas • Water • Cylinder",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "Fetch due bill instantly with Consumer ID",
                                fontSize = 11.sp,
                                color = BrandCyan
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(BrandBlue)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "Fetch →",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Quick Services Grid
            Column {
                Text(
                    text = "Recharge & Bill Pay",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ServiceGridItem(
                        title = "Prepaid",
                        serviceType = ServiceType.MOBILE_PREPAID,
                        color = BrandBlue,
                        onClick = {
                            viewModel.selectService(ServiceType.MOBILE_PREPAID)
                            onNavigateToPlans()
                        }
                    )
                    ServiceGridItem(
                        title = "Postpaid",
                        serviceType = ServiceType.MOBILE_POSTPAID,
                        color = Color(0xFF0284C7),
                        onClick = {
                            viewModel.selectService(ServiceType.MOBILE_POSTPAID)
                            onNavigateToUtility(ServiceType.MOBILE_POSTPAID)
                        }
                    )
                    ServiceGridItem(
                        title = "DTH",
                        serviceType = ServiceType.DTH,
                        color = Color(0xFFEF4444),
                        onClick = {
                            viewModel.selectService(ServiceType.DTH)
                            onNavigateToUtility(ServiceType.DTH)
                        }
                    )
                    ServiceGridItem(
                        title = "FASTag",
                        serviceType = ServiceType.FASTAG,
                        color = Color(0xFF10B981),
                        onClick = {
                            viewModel.selectService(ServiceType.FASTAG)
                            onNavigateToUtility(ServiceType.FASTAG)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ServiceGridItem(
                        title = "Electricity",
                        serviceType = ServiceType.ELECTRICITY,
                        color = Color(0xFFF59E0B),
                        onClick = {
                            viewModel.setUtilityCategory(ServiceType.ELECTRICITY)
                            onNavigateToUtilityBills()
                        }
                    )
                    ServiceGridItem(
                        title = "Piped Gas",
                        serviceType = ServiceType.GAS,
                        color = Color(0xFF00897B),
                        onClick = {
                            viewModel.setUtilityCategory(ServiceType.GAS)
                            onNavigateToUtilityBills()
                        }
                    )
                    ServiceGridItem(
                        title = "Water",
                        serviceType = ServiceType.WATER,
                        color = Color(0xFF0288D1),
                        onClick = {
                            viewModel.setUtilityCategory(ServiceType.WATER)
                            onNavigateToUtilityBills()
                        }
                    )
                    ServiceGridItem(
                        title = "Broadband",
                        serviceType = ServiceType.BROADBAND,
                        color = Color(0xFF8B5CF6),
                        onClick = {
                            viewModel.selectService(ServiceType.BROADBAND)
                            onNavigateToUtility(ServiceType.BROADBAND)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ServiceGridItem(
                        title = "LPG Gas",
                        serviceType = ServiceType.CYLINDER,
                        color = Color(0xFFE64A19),
                        onClick = {
                            viewModel.setUtilityCategory(ServiceType.CYLINDER)
                            onNavigateToUtilityBills()
                        }
                    )
                    ServiceGridItem(
                        title = "Metro Card",
                        serviceType = ServiceType.METRO,
                        color = Color(0xFF06B6D4),
                        onClick = {
                            viewModel.selectService(ServiceType.METRO)
                            onNavigateToUtility(ServiceType.METRO)
                        }
                    )
                    ServiceGridItem(
                        title = "Google Play",
                        serviceType = ServiceType.GOOGLE_PLAY,
                        color = Color(0xFF3B82F6),
                        onClick = {
                            viewModel.selectService(ServiceType.GOOGLE_PLAY)
                            onNavigateToUtility(ServiceType.GOOGLE_PLAY)
                        }
                    )
                    ServiceGridItem(
                        title = "All Bills",
                        serviceType = ServiceType.ELECTRICITY,
                        color = BrandBlue,
                        onClick = {
                            onNavigateToUtilityBills()
                        }
                    )
                }
            }

            // Saved & Frequent Beneficiaries Carousel
            if (beneficiaries.isNotEmpty()) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recent & Saved Recharges",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${beneficiaries.size} Saved",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(beneficiaries) { item ->
                            SavedBeneficiaryCard(
                                beneficiary = item,
                                onRecharge = {
                                    viewModel.repeatRecharge(item) {
                                        onNavigateToPlans()
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Promotional & Offers Banner Carousel
            Column {
                Text(
                    text = "Special Offers & Cashback",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OfferBanner(
                        title = "Flat ₹50 Off on Jio & Airtel",
                        subtitle = "Use Code VOLT50 on plans of ₹299+",
                        tag = "TOP OFFER",
                        gradient = listOf(Color(0xFF0D53FC), Color(0xFF00C6FF))
                    )
                    OfferBanner(
                        title = "Unlimited 5G + Hotstar Free",
                        subtitle = "Quarterly pack with 2GB/day at ₹899",
                        tag = "STREAMING",
                        gradient = listOf(Color(0xFF6C5CE7), Color(0xFFB53471))
                    )
                    OfferBanner(
                        title = "10% Cashback on FASTag",
                        subtitle = "Toll payments with instant wallet bonus",
                        tag = "HIGHWAYS",
                        gradient = listOf(Color(0xFF05C46B), Color(0xFF00D2D3))
                    )
                }
            }

            // Recent Transactions Preview
            if (transactions.isNotEmpty()) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recent Activity",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "View All",
                            fontSize = 13.sp,
                            color = BrandBlue,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onNavigateToTransactions() }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    transactions.take(2).forEach { txn ->
                        TransactionCard(transaction = txn, onClick = onNavigateToTransactions)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showWalletSheet) {
        WalletAddMoneyDialog(
            currentBalance = walletBalance,
            onDismiss = { viewModel.setShowWalletSheet(false) },
            onAddMoney = { amt -> viewModel.addMoneyToWallet(amt) }
        )
    }
}

@Composable
fun ActivePlanStatusCard(onRechargeAhead: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF0D1B3E), Color(0xFF1E293B))
                )
            )
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(24.dp))
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0A2885)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("JIO", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "9876543210 (Primary)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFFF4757).copy(alpha = 0.25f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "Expires in 2 Days",
                        color = Color(0xFFFF6B81),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Today's High-Speed Data",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                    Text(
                        text = "1.8 GB remaining / 2 GB",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "Unlimited 5G Active",
                    color = BrandCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { 0.9f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = BrandCyan,
                trackColor = Color.White.copy(alpha = 0.15f),
                strokeCap = StrokeCap.Round
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recharge ahead to keep validity intact",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )

                Button(
                    onClick = onRechargeAhead,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrandBlue,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("Recharge Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ServiceGridItem(
    title: String,
    serviceType: ServiceType,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(color.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            ServiceIcon(serviceType = serviceType, size = 26.dp, tint = color)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun SavedBeneficiaryCard(
    beneficiary: SavedBeneficiary,
    onRecharge: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(180.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(BrandBlue.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = beneficiary.operatorName.take(3).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = BrandBlue,
                        fontSize = 11.sp
                    )
                }

                if (beneficiary.daysUntilExpiry in 1..3) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFFF4757).copy(alpha = 0.15f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${beneficiary.daysUntilExpiry}d left",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF4757)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = beneficiary.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                maxLines = 1
            )
            Text(
                text = beneficiary.numberOrId,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onRecharge,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Recharge ₹${beneficiary.lastAmount.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun OfferBanner(
    title: String,
    subtitle: String,
    tag: String,
    gradient: List<Color>
) {
    Box(
        modifier = Modifier
            .width(280.dp)
            .height(130.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(gradient))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = 0.25f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = tag,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }
    }
}
