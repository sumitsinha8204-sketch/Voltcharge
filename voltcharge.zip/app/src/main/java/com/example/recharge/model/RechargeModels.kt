package com.example.recharge.model

enum class ServiceType(val title: String, val subtitle: String, val inputLabel: String, val placeholder: String) {
    MOBILE_PREPAID("Prepaid Mobile", "Instant recharge & packs", "Mobile Number", "Enter 10-digit mobile number"),
    MOBILE_POSTPAID("Postpaid Bill", "Fetch & pay monthly bill", "Mobile Number", "Enter 10-digit mobile number"),
    DTH("DTH TV", "Dish, Tata Play & Airtel", "Subscriber ID / VC Number", "Enter 10 or 11 digit Subscriber ID"),
    FASTAG("FASTag Recharge", "Toll payments for vehicles", "Vehicle Registration No.", "e.g. DL 01 AB 1234"),
    ELECTRICITY("Electricity Bill", "State electricity boards", "Consumer / CA Number", "Enter Consumer Account Number"),
    GAS("Piped Gas", "Mahanagar, IGL, Adani Gas", "BP / Customer Number", "Enter Business Partner / Customer No."),
    WATER("Water Bill", "Municipal water boards", "Consumer / RR Number", "Enter Consumer / K-Number"),
    CYLINDER("LPG Cylinder", "Indane, Bharat & HP Gas", "LPG ID / Mobile", "Enter 17-digit LPG ID or Mobile"),
    BROADBAND("Broadband & Fiber", "High-speed internet bills", "Account / Landline Number", "Enter Broadband Account ID"),
    METRO("Metro Card", "Smart card balance top-up", "Metro Card Number", "Enter 8-10 digit card number"),
    GOOGLE_PLAY("Google Play Code", "In-app purchases & games", "Amount / Google ID", "Select or enter code amount")
}

data class Operator(
    val id: String,
    val name: String,
    val serviceType: ServiceType,
    val brandColorHex: Long,
    val logoText: String,
    val circleDependent: Boolean = true
)

data class Circle(
    val id: String,
    val name: String
)

enum class PlanCategory(val displayName: String) {
    POPULAR("Popular"),
    TRUE_5G("True 5G"),
    DAILY_DATA("Daily Data"),
    ANNUAL("Annual / 365D"),
    DATA_BOOSTER("Data Add-on"),
    ENTERTAINMENT_OTT("OTT Bundles"),
    TALKTIME("Top-up / Talktime"),
    VALUE("Value & Validity")
}

data class RechargePlan(
    val id: String,
    val operatorId: String,
    val circle: String = "All Circles",
    val amount: Double,
    val validity: String,
    val dataAllowance: String,
    val voiceCalls: String,
    val smsAllowance: String,
    val category: PlanCategory,
    val description: String,
    val ottSubscriptions: List<String> = emptyList(),
    val isBestSeller: Boolean = false,
    val cashbackOffer: Double = 0.0,
    val is5GUnlimited: Boolean = false
) {
    val perDayPrice: String
        get() {
            val days = validity.filter { it.isDigit() }.toIntOrNull()
            return if (days != null && days > 0) {
                "₹${String.format("%.1f", amount / days)}/day"
            } else {
                "Best Value"
            }
        }
}

data class PromoCode(
    val code: String,
    val title: String,
    val description: String,
    val minAmount: Double,
    val discountAmount: Double,
    val isPercentage: Boolean = false,
    val maxDiscount: Double = 0.0
)

data class RewardScratchCard(
    val id: String,
    val title: String,
    val description: String,
    val cashbackAmount: Double,
    val isScratched: Boolean = false,
    val wonDate: Long = System.currentTimeMillis()
)

enum class PaymentMethod(val id: String, val title: String, val subtitle: String) {
    WALLET("wallet", "Volt Wallet", "Available Balance"),
    UPI_GPAY("upi_gpay", "Google Pay", "Fast UPI Autopay"),
    UPI_PHONEPE("upi_phonepe", "PhonePe", "Direct UPI Payment"),
    UPI_BHIM("upi_bhim", "Paytm / BHIM UPI", "Any UPI App or ID"),
    CARD("card", "Debit / Credit Card", "Visa, Mastercard, RuPay"),
    NET_BANKING("net_banking", "Net Banking", "All Indian & Global Banks")
}

data class FetchedBill(
    val billId: String,
    val consumerId: String,
    val consumerName: String,
    val serviceType: ServiceType,
    val providerName: String,
    val billNumber: String,
    val billDate: String,
    val dueDate: String,
    val amountDue: Double,
    val unitsConsumed: String? = null,
    val billingPeriod: String,
    val lateFee: Double = 0.0,
    val earlyDiscount: Double = 0.0,
    val isOverdue: Boolean = false,
    val address: String? = null
)

