package com.example.recharge.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_beneficiaries")
data class SavedBeneficiary(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val numberOrId: String,
    val serviceType: String,
    val operatorName: String,
    val circleName: String,
    val lastAmount: Double = 0.0,
    val lastRechargeTime: Long = System.currentTimeMillis(),
    val daysUntilExpiry: Int = 0, // e.g. 2 days left
    val isFavorite: Boolean = false
)
