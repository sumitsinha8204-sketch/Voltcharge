package com.example.recharge.data

import com.example.recharge.data.entity.RechargeTransaction
import com.example.recharge.data.entity.SavedBeneficiary
import com.example.recharge.model.Circle
import com.example.recharge.model.FetchedBill
import com.example.recharge.model.Operator
import com.example.recharge.model.PlanCategory
import com.example.recharge.model.PromoCode
import com.example.recharge.model.RechargePlan
import com.example.recharge.model.RewardScratchCard
import com.example.recharge.model.ServiceType

object SampleData {
    val OPERATORS = listOf(
        // Mobile
        Operator("jio", "Jio", ServiceType.MOBILE_PREPAID, 0xFF0A2885, "Jio"),
        Operator("airtel", "Airtel", ServiceType.MOBILE_PREPAID, 0xFFEE1C25, "airtel"),
        Operator("vi", "Vi", ServiceType.MOBILE_PREPAID, 0xFFFFC20E, "Vi"),
        Operator("bsnl", "BSNL", ServiceType.MOBILE_PREPAID, 0xFFFF6A00, "BSNL"),
        Operator("mtnl", "MTNL", ServiceType.MOBILE_PREPAID, 0xFF007ACC, "MTNL"),

        // Postpaid
        Operator("jio_post", "Jio Postpaid Plus", ServiceType.MOBILE_POSTPAID, 0xFF0A2885, "Jio"),
        Operator("airtel_post", "Airtel Postpaid", ServiceType.MOBILE_POSTPAID, 0xFFEE1C25, "airtel"),
        Operator("vi_post", "Vi Max Postpaid", ServiceType.MOBILE_POSTPAID, 0xFFFFC20E, "Vi"),

        // DTH
        Operator("tataplay", "Tata Play", ServiceType.DTH, 0xFFE50914, "Tata Play", false),
        Operator("airteldth", "Airtel Digital TV", ServiceType.DTH, 0xFFEE1C25, "Airtel DTH", false),
        Operator("dishtv", "Dish TV", ServiceType.DTH, 0xFFFF5722, "Dish TV", false),
        Operator("sundirect", "Sun Direct", ServiceType.DTH, 0xFFFF9800, "Sun Direct", false),
        Operator("d2h", "D2H Videocon", ServiceType.DTH, 0xFF2196F3, "D2H", false),

        // FASTag
        Operator("fastag_paytm", "Paytm Payments Bank FASTag", ServiceType.FASTAG, 0xFF00B9F5, "Paytm", false),
        Operator("fastag_icici", "ICICI Bank FASTag", ServiceType.FASTAG, 0xFFBD222A, "ICICI", false),
        Operator("fastag_sbi", "State Bank of India FASTag", ServiceType.FASTAG, 0xFF1D5A9C, "SBI", false),
        Operator("fastag_hdfc", "HDFC Bank FASTag", ServiceType.FASTAG, 0xFF004B8D, "HDFC", false),
        Operator("fastag_axis", "Axis Bank FASTag", ServiceType.FASTAG, 0xFF8F0F3D, "Axis", false),

        // Electricity
        Operator("elec_tata", "Tata Power (Mumbai/Delhi)", ServiceType.ELECTRICITY, 0xFF005691, "Tata", false),
        Operator("elec_adani", "Adani Electricity Mumbai", ServiceType.ELECTRICITY, 0xFF2A7DE1, "Adani", false),
        Operator("elec_bses", "BSES Rajdhani Power Limited", ServiceType.ELECTRICITY, 0xFFE65100, "BSES", false),
        Operator("elec_bescom", "BESCOM (Bangalore Electricity)", ServiceType.ELECTRICITY, 0xFF2E7D32, "BESCOM", false),
        Operator("elec_mseb", "Mahavitaran (MSEDCL)", ServiceType.ELECTRICITY, 0xFFC2185B, "MSEB", false),
        Operator("elec_uppcl", "UPPCL (Urban / Rural)", ServiceType.ELECTRICITY, 0xFFD84315, "UPPCL", false),
        Operator("elec_tangedco", "TANGEDCO (Tamil Nadu)", ServiceType.ELECTRICITY, 0xFF1565C0, "TN ELEC", false),

        // Piped Gas
        Operator("gas_igl", "Indraprastha Gas Limited (IGL)", ServiceType.GAS, 0xFF00796B, "IGL", false),
        Operator("gas_mgl", "Mahanagar Gas Limited (MGL)", ServiceType.GAS, 0xFF00897B, "MGL", false),
        Operator("gas_adani", "Adani Total Gas", ServiceType.GAS, 0xFF0288D1, "Adani", false),
        Operator("gas_ggl", "Gujarat Gas Limited", ServiceType.GAS, 0xFF388E3C, "GGL", false),

        // Water
        Operator("water_djb", "Delhi Jal Board (DJB)", ServiceType.WATER, 0xFF0288D1, "DJB", false),
        Operator("water_bwssb", "Bangalore Water Supply (BWSSB)", ServiceType.WATER, 0xFF0097A7, "BWSSB", false),
        Operator("water_mcgm", "MCGM Water (Mumbai)", ServiceType.WATER, 0xFF1976D2, "MCGM", false),
        Operator("water_hmwssb", "Hyderabad Water Board (HMWSSB)", ServiceType.WATER, 0xFF00838F, "HMWSSB", false),

        // LPG Cylinder
        Operator("cyl_indane", "Indane Gas (Indian Oil)", ServiceType.CYLINDER, 0xFFE64A19, "Indane", false),
        Operator("cyl_bharat", "Bharat Gas (BPCL)", ServiceType.CYLINDER, 0xFFF57C00, "Bharat", false),
        Operator("cyl_hp", "HP Gas (HPCL)", ServiceType.CYLINDER, 0xFFD32F2F, "HP Gas", false),

        // Broadband
        Operator("bb_jio", "JioFiber", ServiceType.BROADBAND, 0xFF0A2885, "JioFiber", false),
        Operator("bb_airtel", "Airtel Xstream Fiber", ServiceType.BROADBAND, 0xFFEE1C25, "Airtel Xstream", false),
        Operator("bb_act", "ACT Fibernet", ServiceType.BROADBAND, 0xFFD32F2F, "ACT", false),

        // Metro
        Operator("metro_delhi", "Delhi Metro Rail (DMRC)", ServiceType.METRO, 0xFFC62828, "DMRC", false),
        Operator("metro_mumbai", "Mumbai Metro Card", ServiceType.METRO, 0xFF1565C0, "Mumbai Metro", false),
        Operator("metro_blr", "Namma Metro Bangalore", ServiceType.METRO, 0xFF2E7D32, "Namma Metro", false),

        // Google Play
        Operator("gplay", "Google Play Recharge Code", ServiceType.GOOGLE_PLAY, 0xFF4285F4, "Google Play", false)
    )

    val CIRCLES = listOf(
        Circle("delhi", "Delhi NCR"),
        Circle("mumbai", "Mumbai"),
        Circle("karnataka", "Karnataka (Bangalore)"),
        Circle("maharashtra", "Maharashtra & Goa"),
        Circle("up_east", "UP East"),
        Circle("up_west", "UP West"),
        Circle("tamil_nadu", "Tamil Nadu & Chennai"),
        Circle("andhra", "Andhra Pradesh & Telangana"),
        Circle("kolkata", "West Bengal & Kolkata"),
        Circle("gujarat", "Gujarat"),
        Circle("rajasthan", "Rajasthan"),
        Circle("kerala", "Kerala"),
        Circle("punjab", "Punjab & Haryana")
    )

    val PROMO_CODES = listOf(
        PromoCode("VOLT50", "Flat ₹50 Off", "Get ₹50 discount on recharges of ₹299 or more", 299.0, 50.0),
        PromoCode("SUPER10", "10% Instant Savings", "Save 10% up to ₹40 on prepaid recharges", 199.0, 10.0, true, 40.0),
        PromoCode("CASHBACK20", "Flat ₹20 Cashback", "Earn ₹20 wallet bonus on any recharge above ₹149", 149.0, 20.0),
        PromoCode("ANNUAL150", "₹150 Off Annual Pack", "Save ₹150 instantly on 365 days plans", 2999.0, 150.0)
    )

    val ALL_PLANS: List<RechargePlan> = listOf(
        // Jio Plans
        RechargePlan(
            id = "jio_349",
            operatorId = "jio",
            amount = 349.0,
            validity = "28 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "Unlimited 5G Data included + JioCinema, JioTV and JioCloud subscriptions.",
            ottSubscriptions = listOf("JioCinema", "JioTV", "JioCloud"),
            isBestSeller = true,
            cashbackOffer = 20.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_299",
            operatorId = "jio",
            amount = 299.0,
            validity = "28 Days",
            dataAllowance = "1.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.DAILY_DATA,
            description = "Standard daily data plan with 42GB total data and unlimited voice calls.",
            ottSubscriptions = listOf("JioTV", "JioCinema"),
            isBestSeller = false,
            cashbackOffer = 15.0
        ),
        RechargePlan(
            id = "jio_399",
            operatorId = "jio",
            amount = 399.0,
            validity = "28 Days",
            dataAllowance = "3 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.TRUE_5G,
            description = "Heavy internet user pack: 3GB/day + Unlimited True 5G data.",
            ottSubscriptions = listOf("JioCinema Premium", "JioTV"),
            isBestSeller = false,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_449",
            operatorId = "jio",
            amount = 449.0,
            validity = "28 Days",
            dataAllowance = "3 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ENTERTAINMENT_OTT,
            description = "Disney+ Hotstar 3 Months Mobile Subscription included with unlimited 5G.",
            ottSubscriptions = listOf("Disney+ Hotstar (3M)", "JioCinema"),
            isBestSeller = true,
            cashbackOffer = 30.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_899",
            operatorId = "jio",
            amount = 899.0,
            validity = "90 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "Quarterly plan: 20GB extra data free + Unlimited 5G for 90 days.",
            ottSubscriptions = listOf("JioCinema", "JioTV"),
            isBestSeller = true,
            cashbackOffer = 40.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_1029",
            operatorId = "jio",
            amount = 1029.0,
            validity = "84 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ENTERTAINMENT_OTT,
            description = "Amazon Prime Lite (84 days) + Unlimited 5G Data included.",
            ottSubscriptions = listOf("Amazon Prime Lite", "JioCinema"),
            isBestSeller = false,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_3599",
            operatorId = "jio",
            amount = 3599.0,
            validity = "365 Days",
            dataAllowance = "2.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ANNUAL,
            description = "Full Year Peace of Mind: 912.5GB Data + Unlimited 5G + Daily 100 SMS.",
            ottSubscriptions = listOf("JioCinema", "JioTV", "JioCloud"),
            isBestSeller = true,
            cashbackOffer = 100.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_61",
            operatorId = "jio",
            amount = 61.0,
            validity = "Existing Plan",
            dataAllowance = "6 GB Bulk",
            voiceCalls = "NA",
            smsAllowance = "NA",
            category = PlanCategory.DATA_BOOSTER,
            description = "5G Upgrade voucher + 6GB high speed 4G/5G data with active plan validity.",
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "jio_29",
            operatorId = "jio",
            amount = 29.0,
            validity = "1 Day",
            dataAllowance = "2 GB",
            voiceCalls = "NA",
            smsAllowance = "NA",
            category = PlanCategory.DATA_BOOSTER,
            description = "Instant 2GB emergency booster pack valid for 24 hours."
        ),
        RechargePlan(
            id = "jio_189",
            operatorId = "jio",
            amount = 189.0,
            validity = "28 Days",
            dataAllowance = "2 GB Total",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "300 SMS",
            category = PlanCategory.VALUE,
            description = "Affordable validity saver with unlimited calling."
        ),

        // Airtel Plans
        RechargePlan(
            id = "airtel_379",
            operatorId = "airtel",
            amount = 379.0,
            validity = "1 Month",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "Unlimited 5G Data, Wynk Music & Apollo 24/7 Circle circle free.",
            ottSubscriptions = listOf("Wynk Music", "Apollo 24/7"),
            isBestSeller = true,
            cashbackOffer = 25.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "airtel_349",
            operatorId = "airtel",
            amount = 349.0,
            validity = "28 Days",
            dataAllowance = "1.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.DAILY_DATA,
            description = "Most loved 1.5GB/day pack with unlimited calls across India.",
            ottSubscriptions = listOf("Wynk Music"),
            isBestSeller = false
        ),
        RechargePlan(
            id = "airtel_549",
            operatorId = "airtel",
            amount = 549.0,
            validity = "28 Days",
            dataAllowance = "3 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ENTERTAINMENT_OTT,
            description = "Disney+ Hotstar 3 Months Mobile + Unlimited 5G Data.",
            ottSubscriptions = listOf("Disney+ Hotstar", "Wynk Music"),
            isBestSeller = true,
            cashbackOffer = 35.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "airtel_859",
            operatorId = "airtel",
            amount = 859.0,
            validity = "84 Days",
            dataAllowance = "1.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "Quarterly plan for 84 days: 126GB total data, unlimited calls & Wynk.",
            ottSubscriptions = listOf("Wynk Music"),
            isBestSeller = true,
            cashbackOffer = 50.0
        ),
        RechargePlan(
            id = "airtel_979",
            operatorId = "airtel",
            amount = 979.0,
            validity = "84 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.TRUE_5G,
            description = "Airtel 5G Plus Unlimited Data + 2GB/day 4G backup + Airtel Xstream Play.",
            ottSubscriptions = listOf("Xstream Play (22+ OTTs)", "Wynk"),
            isBestSeller = true,
            cashbackOffer = 50.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "airtel_3599",
            operatorId = "airtel",
            amount = 3599.0,
            validity = "365 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ANNUAL,
            description = "1 Year Validity + Unlimited 5G data + Xstream Play 22+ OTT premium pack.",
            ottSubscriptions = listOf("Airtel Xstream Play", "Wynk Music", "Apollo 24/7"),
            isBestSeller = true,
            cashbackOffer = 120.0,
            is5GUnlimited = true
        ),
        RechargePlan(
            id = "airtel_22",
            operatorId = "airtel",
            amount = 22.0,
            validity = "1 Day",
            dataAllowance = "1 GB",
            voiceCalls = "NA",
            smsAllowance = "NA",
            category = PlanCategory.DATA_BOOSTER,
            description = "1GB data booster pack valid for 1 day."
        ),
        RechargePlan(
            id = "airtel_77",
            operatorId = "airtel",
            amount = 77.0,
            validity = "Existing Plan",
            dataAllowance = "6 GB Bulk",
            voiceCalls = "NA",
            smsAllowance = "NA",
            category = PlanCategory.DATA_BOOSTER,
            description = "6GB high speed data valid till your current plan expires."
        ),

        // Vi (Vodafone Idea) Plans
        RechargePlan(
            id = "vi_349",
            operatorId = "vi",
            amount = 349.0,
            validity = "28 Days",
            dataAllowance = "1.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "Binge All Night (12am-6am unlimited data) + Weekend Data Rollover + Vi Movies & TV.",
            ottSubscriptions = listOf("Vi Movies & TV"),
            isBestSeller = true,
            cashbackOffer = 20.0
        ),
        RechargePlan(
            id = "vi_409",
            operatorId = "vi",
            amount = 409.0,
            validity = "28 Days",
            dataAllowance = "3.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.DAILY_DATA,
            description = "Heavy Data Delight: 3.5GB/day + Unlimited Night Surf + 2GB backup data.",
            isBestSeller = true,
            cashbackOffer = 30.0
        ),
        RechargePlan(
            id = "vi_859",
            operatorId = "vi",
            amount = 859.0,
            validity = "84 Days",
            dataAllowance = "1.5 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "84 days unlimited calling + Binge All Night + Weekend Rollover.",
            ottSubscriptions = listOf("Vi Movies & TV"),
            isBestSeller = false
        ),
        RechargePlan(
            id = "vi_3199",
            operatorId = "vi",
            amount = 3199.0,
            validity = "365 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ANNUAL,
            description = "Annual Hero Plan: Amazon Prime Video Mobile Edition 1 Year + Binge All Night.",
            ottSubscriptions = listOf("Amazon Prime Video Mobile (1 Year)", "Vi TV"),
            isBestSeller = true,
            cashbackOffer = 100.0
        ),
        RechargePlan(
            id = "vi_19",
            operatorId = "vi",
            amount = 19.0,
            validity = "1 Day",
            dataAllowance = "1 GB",
            voiceCalls = "NA",
            smsAllowance = "NA",
            category = PlanCategory.DATA_BOOSTER,
            description = "Emergency 1GB high speed add-on."
        ),

        // BSNL Plans
        RechargePlan(
            id = "bsnl_199",
            operatorId = "bsnl",
            amount = 199.0,
            validity = "30 Days",
            dataAllowance = "2 GB/day",
            voiceCalls = "Unlimited Any-net",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.POPULAR,
            description = "Best budget plan: 2GB daily data + 100 SMS/day + BSNL Tunes.",
            isBestSeller = true,
            cashbackOffer = 15.0
        ),
        RechargePlan(
            id = "bsnl_397",
            operatorId = "bsnl",
            amount = 397.0,
            validity = "150 Days",
            dataAllowance = "2 GB/day (first 30D)",
            voiceCalls = "Unlimited (first 30D)",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.VALUE,
            description = "Long validity saver: 150 days incoming validity + 30 days active unlimited.",
            isBestSeller = true
        ),
        RechargePlan(
            id = "bsnl_1999",
            operatorId = "bsnl",
            amount = 1999.0,
            validity = "365 Days",
            dataAllowance = "600 GB Bulk",
            voiceCalls = "Truly Unlimited",
            smsAllowance = "100 SMS/day",
            category = PlanCategory.ANNUAL,
            description = "BSNL Super Annual: 600GB lump-sum data no daily cap + 365 days unlimited voice.",
            isBestSeller = true,
            cashbackOffer = 80.0
        ),

        // Top up Talktime plans
        RechargePlan(
            id = "topup_100",
            operatorId = "jio",
            amount = 100.0,
            validity = "Unlimited",
            dataAllowance = "NA",
            voiceCalls = "Talktime: ₹81.75",
            smsAllowance = "NA",
            category = PlanCategory.TALKTIME,
            description = "Standard talktime top-up of ₹81.75 talktime balance with unrestricted validity."
        ),
        RechargePlan(
            id = "topup_500",
            operatorId = "airtel",
            amount = 500.0,
            validity = "Unlimited",
            dataAllowance = "NA",
            voiceCalls = "Talktime: ₹423.73",
            smsAllowance = "NA",
            category = PlanCategory.TALKTIME,
            description = "Full value talktime pack for roaming & non-standard services."
        )
    )

    val INITIAL_BENEFICIARIES = listOf(
        SavedBeneficiary(
            id = 1,
            name = "My Primary Jio",
            numberOrId = "9876543210",
            serviceType = ServiceType.MOBILE_PREPAID.name,
            operatorName = "Jio",
            circleName = "Delhi NCR",
            lastAmount = 349.0,
            lastRechargeTime = System.currentTimeMillis() - (26 * 86400000L),
            daysUntilExpiry = 2,
            isFavorite = true
        ),
        SavedBeneficiary(
            id = 2,
            name = "Mom's Airtel Phone",
            numberOrId = "9810012345",
            serviceType = ServiceType.MOBILE_PREPAID.name,
            operatorName = "Airtel",
            circleName = "Mumbai",
            lastAmount = 859.0,
            lastRechargeTime = System.currentTimeMillis() - (75 * 86400000L),
            daysUntilExpiry = 9,
            isFavorite = true
        ),
        SavedBeneficiary(
            id = 3,
            name = "Living Room Tata Play",
            numberOrId = "1029384756",
            serviceType = ServiceType.DTH.name,
            operatorName = "Tata Play",
            circleName = "All Circles",
            lastAmount = 450.0,
            lastRechargeTime = System.currentTimeMillis() - (20 * 86400000L),
            daysUntilExpiry = 8,
            isFavorite = true
        ),
        SavedBeneficiary(
            id = 4,
            name = "Honda City FASTag",
            numberOrId = "DL 01 AA 1008",
            serviceType = ServiceType.FASTAG.name,
            operatorName = "Paytm Payments Bank FASTag",
            circleName = "All Circles",
            lastAmount = 500.0,
            lastRechargeTime = System.currentTimeMillis() - (15 * 86400000L),
            daysUntilExpiry = 0,
            isFavorite = false
        )
    )

    val INITIAL_TRANSACTIONS = listOf(
        RechargeTransaction(
            id = 1,
            transactionId = "VC-90482183",
            operatorRefId = "JIO-8837194",
            serviceType = ServiceType.MOBILE_PREPAID.name,
            targetNumber = "9876543210",
            operatorName = "Jio",
            circleName = "Delhi NCR",
            planAmount = 349.0,
            walletDeduction = 50.0,
            couponDiscount = 20.0,
            finalAmountPaid = 279.0,
            paymentMethod = "Volt Wallet + UPI",
            status = "SUCCESS",
            planDescription = "2 GB/day + Unlimited True 5G + JioCinema",
            validity = "28 Days",
            dataAllowance = "2 GB/day",
            cashbackEarned = 25.0,
            timestamp = System.currentTimeMillis() - (26 * 86400000L)
        ),
        RechargeTransaction(
            id = 2,
            transactionId = "VC-89210944",
            operatorRefId = "AIRTEL-449102",
            serviceType = ServiceType.MOBILE_PREPAID.name,
            targetNumber = "9810012345",
            operatorName = "Airtel",
            circleName = "Mumbai",
            planAmount = 859.0,
            walletDeduction = 0.0,
            couponDiscount = 50.0,
            finalAmountPaid = 809.0,
            paymentMethod = "Google Pay UPI",
            status = "SUCCESS",
            planDescription = "1.5 GB/day + Truly Unlimited Calls + Wynk",
            validity = "84 Days",
            dataAllowance = "1.5 GB/day",
            cashbackEarned = 50.0,
            timestamp = System.currentTimeMillis() - (75 * 86400000L)
        ),
        RechargeTransaction(
            id = 3,
            transactionId = "VC-88410291",
            operatorRefId = "TATA-993182",
            serviceType = ServiceType.DTH.name,
            targetNumber = "1029384756",
            operatorName = "Tata Play",
            circleName = "All Circles",
            planAmount = 450.0,
            walletDeduction = 100.0,
            couponDiscount = 0.0,
            finalAmountPaid = 350.0,
            paymentMethod = "Volt Wallet",
            status = "SUCCESS",
            planDescription = "Hindi Smart Super HD Pack - 62 Channels",
            validity = "30 Days",
            dataAllowance = "DTH Channels",
            cashbackEarned = 15.0,
            timestamp = System.currentTimeMillis() - (20 * 86400000L)
        )
    )

    val INITIAL_REWARDS = listOf(
        RewardScratchCard(
            id = "rew_1",
            title = "Welcome Cashback",
            description = "Congratulations! Scratch to claim your signup reward.",
            cashbackAmount = 35.0,
            isScratched = false
        ),
        RewardScratchCard(
            id = "rew_2",
            title = "5G Super Recharge Reward",
            description = "Won for high speed 5G plan recharge.",
            cashbackAmount = 25.0,
            isScratched = true
        )
    )

    val SAMPLE_BILLS: List<FetchedBill> = listOf(
        FetchedBill(
            billId = "BILL-ELE-9821",
            consumerId = "102938472",
            consumerName = "Rahul Sharma",
            serviceType = ServiceType.ELECTRICITY,
            providerName = "Tata Power (Mumbai/Delhi)",
            billNumber = "TP-2026-09-8812",
            billDate = "15 Sep 2026",
            dueDate = "02 Oct 2026",
            amountDue = 1480.0,
            unitsConsumed = "214 kWh Units",
            billingPeriod = "12 Aug 2026 - 12 Sep 2026",
            earlyDiscount = 35.0,
            address = "Flat 402, Oakwood Heights, Sector 62, Noida"
        ),
        FetchedBill(
            billId = "BILL-GAS-4491",
            consumerId = "88392019",
            consumerName = "Priya Verma",
            serviceType = ServiceType.GAS,
            providerName = "Indraprastha Gas Limited (IGL)",
            billNumber = "IGL-AUG26-3021",
            billDate = "10 Sep 2026",
            dueDate = "28 Sep 2026",
            amountDue = 620.0,
            unitsConsumed = "28 SCM Units",
            billingPeriod = "01 Jul 2026 - 31 Aug 2026",
            earlyDiscount = 15.0,
            address = "C-12, Mayur Vihar Phase 1, East Delhi"
        ),
        FetchedBill(
            billId = "BILL-WAT-7721",
            consumerId = "55201938",
            consumerName = "Vikram Patel",
            serviceType = ServiceType.WATER,
            providerName = "Delhi Jal Board (DJB)",
            billNumber = "DJB-Q2-94812",
            billDate = "05 Sep 2026",
            dueDate = "26 Sep 2026",
            amountDue = 340.0,
            unitsConsumed = "18 Kilolitres",
            billingPeriod = "Jun 2026 - Aug 2026",
            address = "House 89, Vasant Kunj, New Delhi"
        )
    )
}
