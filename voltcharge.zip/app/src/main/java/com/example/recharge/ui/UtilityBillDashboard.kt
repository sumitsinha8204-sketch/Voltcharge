package com.example.recharge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.recharge.model.FetchedBill
import com.example.recharge.model.Operator
import com.example.recharge.model.ServiceType
import com.example.recharge.ui.components.OperatorBadge
import com.example.recharge.ui.components.ServiceIcon
import com.example.recharge.viewmodel.RechargeViewModel
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandMint

/**
 * UtilityBillDashboard UI:
 * Displays essential utility categories (Electricity, Piped Gas, Water, LPG Cylinder, Broadband),
 * provides consumer ID input with auto-validation and instant fetch, and showcases fetched due bills
 * with breakdown and direct checkout integration.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UtilityBillDashboard(
    viewModel: RechargeViewModel,
    onBack: () -> Unit,
    onProceedToCheckout: () -> Unit
) {
    val activeCategory by viewModel.utilityCategory.collectAsStateWithLifecycle()
    val consumerIdInput by viewModel.consumerIdInput.collectAsStateWithLifecycle()
    val selectedOperator by viewModel.selectedOperator.collectAsStateWithLifecycle()
    val isFetchingBill by viewModel.isFetchingBill.collectAsStateWithLifecycle()
    val fetchedBill by viewModel.fetchedBill.collectAsStateWithLifecycle()
    val billFetchError by viewModel.billFetchError.collectAsStateWithLifecycle()

    var showProviderPicker by remember { mutableStateOf(false) }

    val utilityCategories = listOf(
        ServiceType.ELECTRICITY,
        ServiceType.GAS,
        ServiceType.WATER,
        ServiceType.CYLINDER,
        ServiceType.BROADBAND
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Utility Bill Payments",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Electricity • Gas • Water • Utilities",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("utility_dashboard_back_btn")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Category Selection Tabs / Carousel
            Column {
                Text(
                    text = "Select Bill Category",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    utilityCategories.forEach { category ->
                        val isSelected = activeCategory == category
                        val categoryColor = when (category) {
                            ServiceType.ELECTRICITY -> Color(0xFFF59E0B)
                            ServiceType.GAS -> Color(0xFF00897B)
                            ServiceType.WATER -> Color(0xFF0288D1)
                            ServiceType.CYLINDER -> Color(0xFFE64A19)
                            ServiceType.BROADBAND -> Color(0xFF8B5CF6)
                            else -> BrandBlue
                        }

                        UtilityCategoryCard(
                            serviceType = category,
                            isSelected = isSelected,
                            color = categoryColor,
                            onClick = {
                                viewModel.setUtilityCategory(category)
                            },
                            modifier = Modifier.testTag("cat_card_${category.name.lowercase()}")
                        )
                    }
                }
            }

            // 2. Bill Fetcher Card
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f),
                        RoundedCornerShape(22.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    // Header with Icon & Active Service Name
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(BrandBlue.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                ServiceIcon(serviceType = activeCategory, size = 18.dp, tint = BrandBlue)
                            }
                            Column {
                                Text(
                                    text = activeCategory.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "BBPS Certified Fetch",
                                    fontSize = 11.sp,
                                    color = BrandMint,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "INSTANT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Provider / Board Selector Box
                    Text(
                        text = "Selected Biller / Board",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { showProviderPicker = true }
                            .padding(12.dp)
                            .testTag("utility_board_picker_btn")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OperatorBadge(operator = selectedOperator, size = 32.dp)
                                Column {
                                    Text(
                                        text = selectedOperator.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Tap to change biller",
                                        fontSize = 11.sp,
                                        color = BrandBlue
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Change Biller",
                                tint = BrandBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Consumer ID Input Field
                    Text(
                        text = activeCategory.inputLabel,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = consumerIdInput,
                        onValueChange = { viewModel.setConsumerIdInput(it) },
                        placeholder = { Text(activeCategory.placeholder, fontSize = 13.sp) },
                        trailingIcon = {
                            if (consumerIdInput.isNotEmpty()) {
                                IconButton(
                                    onClick = { viewModel.setConsumerIdInput("") },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        isError = billFetchError != null,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("consumer_id_input")
                    )

                    // Quick Demo / Sample IDs
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Sample IDs:",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val sampleIds = when (activeCategory) {
                            ServiceType.ELECTRICITY -> listOf("102938472", "993810294")
                            ServiceType.GAS -> listOf("88392019", "44910283")
                            ServiceType.WATER -> listOf("55201938", "12903847")
                            ServiceType.CYLINDER -> listOf("9876543210")
                            else -> listOf("102938472")
                        }
                        sampleIds.forEach { sampleId ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BrandBlue.copy(alpha = 0.1f))
                                    .clickable { viewModel.setConsumerIdInput(sampleId) }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                    .testTag("sample_id_chip_$sampleId")
                            ) {
                                Text(
                                    text = sampleId,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = BrandBlue
                                )
                            }
                        }
                    }

                    // Error Message
                    if (billFetchError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = billFetchError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Fetch Bill Button
                    Button(
                        onClick = { viewModel.fetchDueBill() },
                        enabled = !isFetchingBill && consumerIdInput.isNotEmpty(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("fetch_bill_btn")
                    ) {
                        if (isFetchingBill) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Fetching from Biller...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(imageVector = Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Fetch Due Bill", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 3. Fetched Due Bill Card
            AnimatedVisibility(
                visible = fetchedBill != null,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -20 })
            ) {
                if (fetchedBill != null) {
                    DueBillDetailsCard(
                        bill = fetchedBill!!,
                        onPayNow = {
                            viewModel.proceedToPayFetchedBill {
                                onProceedToCheckout()
                            }
                        },
                        onDismiss = { viewModel.clearFetchedBill() }
                    )
                }
            }

            // 4. Saved Utility Billers & Reminders
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Saved Billers & Alerts",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = BrandAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Reminders ON",
                            fontSize = 11.sp,
                            color = BrandAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                SavedBillerItem(
                    title = "Home Electricity (Tata Power)",
                    consumerId = "CA: 102938472",
                    serviceType = ServiceType.ELECTRICITY,
                    statusText = "Due 02 Oct (₹1,480)",
                    isUrgent = true,
                    onClick = {
                        viewModel.setUtilityCategory(ServiceType.ELECTRICITY)
                        viewModel.setConsumerIdInput("102938472")
                        viewModel.fetchDueBill()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                SavedBillerItem(
                    title = "Kitchen Piped Gas (IGL)",
                    consumerId = "BP: 88392019",
                    serviceType = ServiceType.GAS,
                    statusText = "Due 28 Sep (₹620)",
                    isUrgent = false,
                    onClick = {
                        viewModel.setUtilityCategory(ServiceType.GAS)
                        viewModel.setConsumerIdInput("88392019")
                        viewModel.fetchDueBill()
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                SavedBillerItem(
                    title = "Apartment Water (Delhi Jal Board)",
                    consumerId = "K-No: 55201938",
                    serviceType = ServiceType.WATER,
                    statusText = "Paid • Next in 45 days",
                    isUrgent = false,
                    onClick = {
                        viewModel.setUtilityCategory(ServiceType.WATER)
                        viewModel.setConsumerIdInput("55201938")
                        viewModel.fetchDueBill()
                    }
                )
            }

            // 5. BBPS Trust & Assurance Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(BrandMint.copy(alpha = 0.08f))
                    .border(1.dp, BrandMint.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = BrandMint,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Bharat BillPay (BBPS) Secured",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Instant electronic confirmation with official receipt and zero transaction fee.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Provider / Biller Selection Modal
    if (showProviderPicker) {
        val providers = viewModel.getOperatorsForCurrentService()
        Dialog(onDismissRequest = { showProviderPicker = false }) {
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Select ${activeCategory.title} Provider",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showProviderPicker = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyColumn(
                        modifier = Modifier.height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(providers) { provider ->
                            val isSelected = selectedOperator.id == provider.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) BrandBlue.copy(alpha = 0.12f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                    .clickable {
                                        viewModel.setOperator(provider)
                                        showProviderPicker = false
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OperatorBadge(operator = provider, size = 32.dp)
                                    Text(
                                        text = provider.name,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = BrandBlue
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UtilityCategoryCard(
    serviceType: ServiceType,
    isSelected: Boolean,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(115.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (isSelected) color.copy(alpha = 0.15f)
                else MaterialTheme.colorScheme.surface
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) color else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) color else color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                ServiceIcon(
                    serviceType = serviceType,
                    size = 22.dp,
                    tint = if (isSelected) Color.White else color
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = when (serviceType) {
                    ServiceType.ELECTRICITY -> "Electricity"
                    ServiceType.GAS -> "Piped Gas"
                    ServiceType.WATER -> "Water"
                    ServiceType.CYLINDER -> "LPG Gas"
                    ServiceType.BROADBAND -> "Broadband"
                    else -> serviceType.title
                },
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun DueBillDetailsCard(
    bill: FetchedBill,
    onPayNow: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                )
            )
            .border(1.5.dp, BrandCyan.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
            .padding(18.dp)
            .testTag("fetched_due_bill_card")
    ) {
        Column {
            // Top Row: Bill Header & Close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BrandMint.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "BILL VERIFIED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandMint
                        )
                    }
                    Text(
                        text = bill.providerName,
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Due Amount & Due Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "TOTAL AMOUNT DUE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "₹${bill.amountDue.toInt()}",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(BrandAmber.copy(alpha = 0.25f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Due: ${bill.dueDate}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandAmber
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Details Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BillDetailItem("Consumer Name", bill.consumerName)
                BillDetailItem("Account / Consumer ID", bill.consumerId)
                BillDetailItem("Bill Number", bill.billNumber)
                BillDetailItem("Billing Period", bill.billingPeriod)
                if (bill.unitsConsumed != null) {
                    BillDetailItem("Consumption", bill.unitsConsumed)
                }
                if (bill.earlyDiscount > 0) {
                    BillDetailItem(
                        "Early Payment Rebate",
                        "- ₹${bill.earlyDiscount.toInt()}",
                        highlightColor = BrandMint
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Pay Action Button
            Button(
                onClick = onPayNow,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandBlue,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pay_due_bill_now_btn")
            ) {
                Text(
                    text = "Pay Bill of ₹${bill.amountDue.toInt()}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun BillDetailItem(
    label: String,
    value: String,
    highlightColor: Color = Color.White
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color.White.copy(alpha = 0.7f)
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = highlightColor
        )
    }
}

@Composable
fun SavedBillerItem(
    title: String,
    consumerId: String,
    serviceType: ServiceType,
    statusText: String,
    isUrgent: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                1.dp,
                if (isUrgent) BrandAmber.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f),
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        when (serviceType) {
                            ServiceType.ELECTRICITY -> Color(0xFFF59E0B).copy(alpha = 0.12f)
                            ServiceType.GAS -> Color(0xFF00897B).copy(alpha = 0.12f)
                            ServiceType.WATER -> Color(0xFF0288D1).copy(alpha = 0.12f)
                            else -> BrandBlue.copy(alpha = 0.12f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                ServiceIcon(
                    serviceType = serviceType,
                    size = 20.dp,
                    tint = when (serviceType) {
                        ServiceType.ELECTRICITY -> Color(0xFFF59E0B)
                        ServiceType.GAS -> Color(0xFF00897B)
                        ServiceType.WATER -> Color(0xFF0288D1)
                        else -> BrandBlue
                    }
                )
            }

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = consumerId,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = statusText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isUrgent) BrandAmber else BrandMint
            )
            Text(
                text = "Tap to fetch",
                fontSize = 10.sp,
                color = BrandBlue
            )
        }
    }
}
