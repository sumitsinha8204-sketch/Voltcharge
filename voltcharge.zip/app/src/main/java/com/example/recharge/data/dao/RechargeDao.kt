package com.example.recharge.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.recharge.data.entity.RechargeTransaction
import com.example.recharge.data.entity.SavedBeneficiary
import kotlinx.coroutines.flow.Flow

@Dao
interface RechargeDao {
    // Transactions
    @Query("SELECT * FROM recharge_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<RechargeTransaction>>

    @Query("SELECT * FROM recharge_transactions WHERE serviceType = :serviceType ORDER BY timestamp DESC")
    fun getTransactionsByService(serviceType: String): Flow<List<RechargeTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: RechargeTransaction): Long

    @Query("SELECT * FROM recharge_transactions WHERE transactionId = :txnId LIMIT 1")
    suspend fun getTransactionById(txnId: String): RechargeTransaction?

    // Beneficiaries
    @Query("SELECT * FROM saved_beneficiaries ORDER BY isFavorite DESC, lastRechargeTime DESC")
    fun getAllBeneficiaries(): Flow<List<SavedBeneficiary>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeneficiary(beneficiary: SavedBeneficiary): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBeneficiaries(beneficiaries: List<SavedBeneficiary>)

    @Update
    suspend fun updateBeneficiary(beneficiary: SavedBeneficiary)

    @Query("SELECT * FROM saved_beneficiaries WHERE numberOrId = :numberOrId LIMIT 1")
    suspend fun findBeneficiaryByNumber(numberOrId: String): SavedBeneficiary?

    @Query("DELETE FROM saved_beneficiaries WHERE id = :id")
    suspend fun deleteBeneficiaryById(id: Long)
}
