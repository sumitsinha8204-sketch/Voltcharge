package com.example.recharge.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recharge_transactions")
data class RechargeTransaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val transactionId: String,
    val operatorRefId: String,
    val serviceType: String,
    val targetNumber: String,
    val operatorName: String,
    val circleName: String,
    val planAmount: Double,
    val walletDeduction: Double,
    val couponDiscount: Double,
    val finalAmountPaid: Double,
    val paymentMethod: String,
    val status: String, // "SUCCESS", "PENDING", "FAILED"
    val planDescription: String,
    val validity: String,
    val dataAllowance: String,
    val cashbackEarned: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
)
