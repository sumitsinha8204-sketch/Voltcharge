package com.example.recharge.data.repository

import com.example.recharge.data.SampleData
import com.example.recharge.data.dao.RechargeDao
import com.example.recharge.data.entity.RechargeTransaction
import com.example.recharge.data.entity.SavedBeneficiary
import com.example.recharge.model.Circle
import com.example.recharge.model.Operator
import com.example.recharge.model.PlanCategory
import com.example.recharge.model.PromoCode
import com.example.recharge.model.RechargePlan
import com.example.recharge.model.RewardScratchCard
import com.example.recharge.model.ServiceType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RechargeRepository(
    private val dao: RechargeDao,
    private val coroutineScope: CoroutineScope
) {
    val allTransactions: Flow<List<RechargeTransaction>> = dao.getAllTransactions()
    val allBeneficiaries: Flow<List<SavedBeneficiary>> = dao.getAllBeneficiaries()

    // In-memory persistent states for wallet and dynamic rewards
    private val _walletBalance = MutableStateFlow(450.00)
    val walletBalance: StateFlow<Double> = _walletBalance.asStateFlow()

    private val _scratchCards = MutableStateFlow<List<RewardScratchCard>>(SampleData.INITIAL_REWARDS)
    val scratchCards: StateFlow<List<RewardScratchCard>> = _scratchCards.asStateFlow()

    init {
        // Seed initial data asynchronously if database is empty
        coroutineScope.launch(Dispatchers.IO) {
            val existingTx = dao.getAllTransactions().first()
            if (existingTx.isEmpty()) {
                SampleData.INITIAL_TRANSACTIONS.forEach {
                    dao.insertTransaction(it)
                }
            }
            val existingBeneficiaries = dao.getAllBeneficiaries().first()
            if (existingBeneficiaries.isEmpty()) {
                dao.insertBeneficiaries(SampleData.INITIAL_BENEFICIARIES)
            }
        }
    }

    suspend fun addTransaction(transaction: RechargeTransaction): Long = withContext(Dispatchers.IO) {
        val id = dao.insertTransaction(transaction)

        // Automatically update or add beneficiary
        val existing = dao.findBeneficiaryByNumber(transaction.targetNumber)
        if (existing != null) {
            dao.updateBeneficiary(
                existing.copy(
                    lastAmount = transaction.planAmount,
                    lastRechargeTime = System.currentTimeMillis(),
                    daysUntilExpiry = 28
                )
            )
        } else {
            dao.insertBeneficiary(
                SavedBeneficiary(
                    name = "${transaction.operatorName} User",
                    numberOrId = transaction.targetNumber,
                    serviceType = transaction.serviceType,
                    operatorName = transaction.operatorName,
                    circleName = transaction.circleName,
                    lastAmount = transaction.planAmount,
                    lastRechargeTime = System.currentTimeMillis(),
                    daysUntilExpiry = 28,
                    isFavorite = false
                )
            )
        }

        // Award a new scratch card for successful recharge!
        val randomCashback = listOf(15.0, 20.0, 30.0, 50.0, 75.0).random()
        val newCard = RewardScratchCard(
            id = "rew_${System.currentTimeMillis()}",
            title = "Recharge Cashback Reward",
            description = "Won for ₹${transaction.planAmount.toInt()} recharge on ${transaction.targetNumber}",
            cashbackAmount = randomCashback,
            isScratched = false
        )
        _scratchCards.value = listOf(newCard) + _scratchCards.value

        id
    }

    fun deductWallet(amount: Double) {
        _walletBalance.value = (_walletBalance.value - amount).coerceAtLeast(0.0)
    }

    fun creditWallet(amount: Double) {
        _walletBalance.value = _walletBalance.value + amount
    }

    fun scratchCard(cardId: String) {
        val current = _scratchCards.value.toMutableList()
        val index = current.indexOfFirst { it.id == cardId }
        if (index != -1 && !current[index].isScratched) {
            val card = current[index]
            current[index] = card.copy(isScratched = true)
            _scratchCards.value = current
            creditWallet(card.cashbackAmount)
        }
    }

    suspend fun toggleFavorite(beneficiary: SavedBeneficiary) = withContext(Dispatchers.IO) {
        dao.updateBeneficiary(beneficiary.copy(isFavorite = !beneficiary.isFavorite))
    }

    suspend fun deleteBeneficiary(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteBeneficiaryById(id)
    }

    fun getPlansForOperator(operatorId: String, circle: String? = null): List<RechargePlan> {
        return SampleData.ALL_PLANS.filter { it.operatorId.equals(operatorId, ignoreCase = true) }
    }

    fun getOperators(serviceType: ServiceType): List<Operator> {
        return SampleData.OPERATORS.filter { it.serviceType == serviceType }
    }

    fun getCircles(): List<Circle> = SampleData.CIRCLES

    fun getPromoCodes(): List<PromoCode> = SampleData.PROMO_CODES
}
