package com.example.recharge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.recharge.data.SampleData
import com.example.recharge.model.Circle
import com.example.recharge.model.Operator
import com.example.recharge.model.PlanCategory
import com.example.recharge.model.RechargePlan
import com.example.recharge.ui.components.OperatorBadge
import com.example.recharge.viewmodel.RechargeViewModel
import com.example.ui.theme.BrandAmber
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandCyan
import com.example.ui.theme.BrandMint

enum class DataFilter(val label: String) {
    ALL("All Data"),
    ONE_GB("1 GB/d"),
    ONE_POINT_FIVE("1.5 GB/d"),
    TWO_GB("2 GB/d"),
    THREE_GB("2.5+ GB/d"),
    TRUE_5G("⚡ True 5G"),
    BOOSTER("Add-on")
}

enum class ValidityFilter(val label: String) {
    ALL("All Validity"),
    SHORT("28 Days"),
    MEDIUM("56-84 Days"),
    ANNUAL("365 Days")
}

enum class PriceFilter(val label: String) {
    ALL("All Prices"),
    UNDER_200("Under ₹200"),
    MID_200_500("₹200 - ₹500"),
    HIGH_500_1000("₹500 - ₹1000"),
    ANNUAL_1000_PLUS("₹1000+")
}

enum class SortOrder(val label: String) {
    POPULAR("Popularity"),
    PRICE_LOW_HIGH("Price: Low to High"),
    PRICE_HIGH_LOW("Price: High to Low"),
    VALIDITY("Validity")
}

/**
 * PlanBrowser Screen:
 * Allows users to search and filter mobile recharge plans by data allowance,
 * validity, and price bracket, with instant quick recharge checkout.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanBrowser(
    viewModel: RechargeViewModel,
    onBack: () -> Unit,
    onProceedToCheckout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedOperator by viewModel.selectedOperator.collectAsStateWithLifecycle()
    val selectedCircle by viewModel.selectedCircle.collectAsStateWithLifecycle()
    val targetNumber by viewModel.targetNumber.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedDataFilter by remember { mutableStateOf(DataFilter.ALL) }
    var selectedValidityFilter by remember { mutableStateOf(ValidityFilter.ALL) }
    var selectedPriceFilter by remember { mutableStateOf(PriceFilter.ALL) }
    var selectedSortOrder by remember { mutableStateOf(SortOrder.POPULAR) }

    var planForQuickRecharge by remember { mutableStateOf<RechargePlan?>(null) }
    var showOperatorDialog by remember { mutableStateOf(false) }

    // Operator Plans
    val basePlans = remember(selectedOperator) {
        SampleData.ALL_PLANS.filter { it.operatorId == selectedOperator.id }
            .ifEmpty { SampleData.ALL_PLANS.filter { it.operatorId == "jio" } }
    }

    // Filter & Sort Logic
    val filteredPlans by remember(
        basePlans,
        searchQuery,
        selectedDataFilter,
        selectedValidityFilter,
        selectedPriceFilter,
        selectedSortOrder
    ) {
        derivedStateOf {
            basePlans.filter { plan ->
                // 1. Text Search Filter
                val matchesSearch = if (searchQuery.isBlank()) true else {
                    val q = searchQuery.trim().lowercase()
                    plan.amount.toInt().toString().contains(q) ||
                        plan.dataAllowance.lowercase().contains(q) ||
                        plan.validity.lowercase().contains(q) ||
                        plan.description.lowercase().contains(q) ||
                        plan.ottSubscriptions.any { it.lowercase().contains(q) }
                }

                // 2. Data Allowance Filter
                val matchesData = when (selectedDataFilter) {
                    DataFilter.ALL -> true
                    DataFilter.ONE_GB -> plan.dataAllowance.startsWith("1 GB")
                    DataFilter.ONE_POINT_FIVE -> plan.dataAllowance.startsWith("1.5 GB")
                    DataFilter.TWO_GB -> plan.dataAllowance.startsWith("2 GB")
                    DataFilter.THREE_GB -> plan.dataAllowance.startsWith("2.5 GB") || plan.dataAllowance.startsWith("3 GB")
                    DataFilter.TRUE_5G -> plan.is5GUnlimited
                    DataFilter.BOOSTER -> plan.dataAllowance.contains("Bulk", ignoreCase = true) || plan.validity.contains("Existing", ignoreCase = true)
                }

                // 3. Validity Filter
                val matchesValidity = when (selectedValidityFilter) {
                    ValidityFilter.ALL -> true
                    ValidityFilter.SHORT -> plan.validity.contains("28") || plan.validity.contains("24") || plan.validity.contains("30")
                    ValidityFilter.MEDIUM -> plan.validity.contains("56") || plan.validity.contains("84") || plan.validity.contains("90")
                    ValidityFilter.ANNUAL -> plan.validity.contains("365") || plan.validity.contains("336")
                }

                // 4. Price Bracket Filter
                val matchesPrice = when (selectedPriceFilter) {
                    PriceFilter.ALL -> true
                    PriceFilter.UNDER_200 -> plan.amount < 200
                    PriceFilter.MID_200_500 -> plan.amount in 200.0..500.0
                    PriceFilter.HIGH_500_1000 -> plan.amount in 500.0..1000.0
                    PriceFilter.ANNUAL_1000_PLUS -> plan.amount >= 1000.0
                }

                matchesSearch && matchesData && matchesValidity && matchesPrice
            }.let { list ->
                // Sorting
                when (selectedSortOrder) {
                    SortOrder.POPULAR -> list.sortedByDescending { it.isBestSeller || it.category == PlanCategory.POPULAR }
                    SortOrder.PRICE_LOW_HIGH -> list.sortedBy { it.amount }
                    SortOrder.PRICE_HIGH_LOW -> list.sortedByDescending { it.amount }
                    SortOrder.VALIDITY -> list.sortedByDescending {
                        it.validity.filter { c -> c.isDigit() }.toIntOrNull() ?: 0
                    }
                }
            }
        }
    }

    val hasActiveFilters = selectedDataFilter != DataFilter.ALL ||
        selectedValidityFilter != ValidityFilter.ALL ||
        selectedPriceFilter != PriceFilter.ALL ||
        searchQuery.isNotBlank()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = targetNumber.ifEmpty { "Plan Browser" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { showOperatorDialog = true }
                        ) {
                            Text(
                                text = "${selectedOperator.name} • ${selectedCircle.name}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = BrandBlue
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Change Operator",
                                tint = BrandBlue,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("plan_browser_back_btn")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (hasActiveFilters) {
                        TextButton(
                            onClick = {
                                searchQuery = ""
                                selectedDataFilter = DataFilter.ALL
                                selectedValidityFilter = ValidityFilter.ALL
                                selectedPriceFilter = PriceFilter.ALL
                            },
                            modifier = Modifier.testTag("reset_filters_btn")
                        ) {
                            Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandBlue)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset", fontSize = 12.sp, color = BrandBlue, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Input Field
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search ₹ amount, 2GB, 5G, validity or OTT...", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = BrandBlue)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Search),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("plan_browser_search_input")
                )
            }

            // Multi-dimensional Filter Chips Section (Data, Validity, Price)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    )
                    .padding(vertical = 8.dp)
            ) {
                // Row 1: Data Allowance Filters
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Data:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    DataFilter.values().forEach { filter ->
                        val isSelected = selectedDataFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedDataFilter = filter },
                            label = { Text(filter.label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandBlue,
                                selectedLabelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) BrandBlue else MaterialTheme.colorScheme.outlineVariant
                            ),
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier.testTag("filter_data_${filter.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Row 2: Validity & Price Filters
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Validity:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ValidityFilter.values().forEach { filter ->
                        val isSelected = selectedValidityFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedValidityFilter = filter },
                            label = { Text(filter.label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0F172A),
                                selectedLabelColor = Color.White
                            ),
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier.testTag("filter_val_${filter.name.lowercase()}")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Price:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    PriceFilter.values().forEach { filter ->
                        val isSelected = selectedPriceFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedPriceFilter = filter },
                            label = { Text(filter.label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandMint,
                                selectedLabelColor = Color.White
                            ),
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier.testTag("filter_price_${filter.name.lowercase()}")
                        )
                    }
                }
            }

            // Results Counter & Sort Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredPlans.size} Plans Available",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Quick Sort Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "Sort:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .clickable {
                                // Cycle sort order
                                val orders = SortOrder.values()
                                val nextIndex = (selectedSortOrder.ordinal + 1) % orders.size
                                selectedSortOrder = orders[nextIndex]
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("sort_order_toggle_btn")
                    ) {
                        Text(
                            text = selectedSortOrder.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandBlue
                        )
                    }
                }
            }

            // Filtered Plans List
            if (filteredPlans.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No recharge plans found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try adjusting your search query, data, or price filters.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            searchQuery = ""
                            selectedDataFilter = DataFilter.ALL
                            selectedValidityFilter = ValidityFilter.ALL
                            selectedPriceFilter = PriceFilter.ALL
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Clear All Filters")
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredPlans, key = { it.id }) { plan ->
                        PlanBrowserCard(
                            plan = plan,
                            onQuickRechargeClick = {
                                planForQuickRecharge = plan
                            },
                            onSelectPlan = {
                                viewModel.selectPlan(plan)
                                onProceedToCheckout()
                            }
                        )
                    }
                }
            }
        }
    }

    // Quick Recharge Modal Bottom Sheet
    planForQuickRecharge?.let { plan ->
        ModalBottomSheet(
            onDismissRequest = { planForQuickRecharge = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Quick Recharge",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${selectedOperator.name} • ${targetNumber.ifEmpty { "Primary Number" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandMint.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "1-TAP PAY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = BrandMint
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Plan Summary Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "₹${plan.amount.toInt()}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BrandBlue
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (plan.is5GUnlimited) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                Brush.horizontalGradient(listOf(BrandBlue, BrandCyan))
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("True 5G", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF0F172A))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(plan.validity, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${plan.dataAllowance} • Truly Unlimited Voice Calls",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = plan.description,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        viewModel.selectPlan(plan)
                        planForQuickRecharge = null
                        onProceedToCheckout()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_quick_recharge_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Proceed to Pay ₹${plan.amount.toInt()}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    // Operator Switcher Dialog
    if (showOperatorDialog) {
        Dialog(onDismissRequest = { showOperatorDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Select Mobile Operator",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showOperatorDialog = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val mobileOperators = SampleData.OPERATORS.filter { it.serviceType.name.startsWith("MOBILE") }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        mobileOperators.forEach { op ->
                            val isSelected = selectedOperator.id == op.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) BrandBlue.copy(alpha = 0.12f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                    .clickable {
                                        viewModel.setOperator(op)
                                        showOperatorDialog = false
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OperatorBadge(operator = op, size = 32.dp)
                                    Text(text = op.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                }
                                if (isSelected) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = BrandBlue)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Individual Plan Card with comprehensive specs, OTT perks, and quick recharge trigger.
 */
@Composable
fun PlanBrowserCard(
    plan: RechargePlan,
    onQuickRechargeClick: () -> Unit,
    onSelectPlan: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f),
                RoundedCornerShape(20.dp)
            )
            .testTag("plan_card_${plan.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Price & Badges Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "₹${plan.amount.toInt()}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = plan.perDayPrice,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (plan.is5GUnlimited) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    Brush.horizontalGradient(listOf(BrandBlue, BrandCyan))
                                )
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                                Text("True 5G", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            }
                        }
                    }
                    if (plan.isBestSeller || plan.category == PlanCategory.POPULAR) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(BrandAmber.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text("POPULAR", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BrandAmber)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Specs Grid (Validity, Data, Calls)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PlanSpecItem("VALIDITY", plan.validity)
                PlanSpecItem("DATA", plan.dataAllowance)
                PlanSpecItem("CALLS", "Unlimited")
                PlanSpecItem("SMS", "100/day")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // OTT Subscriptions Row (if included)
            if (plan.ottSubscriptions.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Tv, contentDescription = null, modifier = Modifier.size(14.dp), tint = BrandBlue)
                    Text(
                        text = "Includes: ${plan.ottSubscriptions.joinToString(" + ")}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BrandBlue
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Plan Description
            Text(
                text = plan.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Recharge and Detail Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onQuickRechargeClick,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("quick_recharge_btn_${plan.id}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandBlue)
                ) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(15.dp), tint = BrandBlue)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Quick Recharge", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onSelectPlan,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                    modifier = Modifier
                        .weight(1.1f)
                        .height(44.dp)
                        .testTag("select_plan_btn_${plan.id}")
                ) {
                    Text("Recharge ₹${plan.amount.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PlanSpecItem(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}
