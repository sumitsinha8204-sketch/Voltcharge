package com.example.recharge.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.recharge.data.AppDatabase
import com.example.recharge.data.SampleData
import com.example.recharge.data.entity.RechargeTransaction
import com.example.recharge.data.entity.SavedBeneficiary
import com.example.recharge.data.repository.RechargeRepository
import com.example.recharge.model.Circle
import com.example.recharge.model.FetchedBill
import com.example.recharge.model.Operator
import com.example.recharge.model.PaymentMethod
import com.example.recharge.model.PlanCategory
import com.example.recharge.model.PromoCode
import com.example.recharge.model.RechargePlan
import com.example.recharge.model.RewardScratchCard
import com.example.recharge.model.ServiceType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

data class CheckoutCalculation(
    val baseAmount: Double,
    val couponDiscount: Double,
    val walletDeduction: Double,
    val payableAmount: Double,
    val estimatedCashback: Double
)

class RechargeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RechargeRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = RechargeRepository(database.rechargeDao(), viewModelScope)
    }

    val transactions: StateFlow<List<RechargeTransaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val beneficiaries: StateFlow<List<SavedBeneficiary>> = repository.allBeneficiaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val walletBalance: StateFlow<Double> = repository.walletBalance
    val scratchCards: StateFlow<List<RewardScratchCard>> = repository.scratchCards

    // Active selection & flow
    private val _selectedService = MutableStateFlow(ServiceType.MOBILE_PREPAID)
    val selectedService: StateFlow<ServiceType> = _selectedService.asStateFlow()

    private val _targetNumber = MutableStateFlow("9876543210")
    val targetNumber: StateFlow<String> = _targetNumber.asStateFlow()

    private val _selectedOperator = MutableStateFlow(SampleData.OPERATORS.first())
    val selectedOperator: StateFlow<Operator> = _selectedOperator.asStateFlow()

    private val _selectedCircle = MutableStateFlow(SampleData.CIRCLES.first())
    val selectedCircle: StateFlow<Circle> = _selectedCircle.asStateFlow()

    private val _selectedPlan = MutableStateFlow<RechargePlan?>(null)
    val selectedPlan: StateFlow<RechargePlan?> = _selectedPlan.asStateFlow()

    private val _customAmount = MutableStateFlow("")
    val customAmount: StateFlow<String> = _customAmount.asStateFlow()

    private val _appliedPromo = MutableStateFlow<PromoCode?>(null)
    val appliedPromo: StateFlow<PromoCode?> = _appliedPromo.asStateFlow()

    private val _useWalletBalance = MutableStateFlow(false)
    val useWalletBalance: StateFlow<Boolean> = _useWalletBalance.asStateFlow()

    private val _selectedPaymentMethod = MutableStateFlow(PaymentMethod.UPI_GPAY)
    val selectedPaymentMethod: StateFlow<PaymentMethod> = _selectedPaymentMethod.asStateFlow()

    // Processing animation states
    private val _isProcessingPayment = MutableStateFlow(false)
    val isProcessingPayment: StateFlow<Boolean> = _isProcessingPayment.asStateFlow()

    private val _paymentProcessingStep = MutableStateFlow(0)
    val paymentProcessingStep: StateFlow<Int> = _paymentProcessingStep.asStateFlow()

    private val _lastTransaction = MutableStateFlow<RechargeTransaction?>(null)
    val lastTransaction: StateFlow<RechargeTransaction?> = _lastTransaction.asStateFlow()

    // Filters & Comparison
    private val _planSearchQuery = MutableStateFlow("")
    val planSearchQuery: StateFlow<String> = _planSearchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<PlanCategory?>(PlanCategory.POPULAR)
    val selectedCategory: StateFlow<PlanCategory?> = _selectedCategory.asStateFlow()

    private val _comparisonPlans = MutableStateFlow<List<RechargePlan>>(emptyList())
    val comparisonPlans: StateFlow<List<RechargePlan>> = _comparisonPlans.asStateFlow()

    private val _showComparisonSheet = MutableStateFlow(false)
    val showComparisonSheet: StateFlow<Boolean> = _showComparisonSheet.asStateFlow()

    // Sheets
    private val _showWalletSheet = MutableStateFlow(false)
    val showWalletSheet: StateFlow<Boolean> = _showWalletSheet.asStateFlow()

    private val _showPromoSheet = MutableStateFlow(false)
    val showPromoSheet: StateFlow<Boolean> = _showPromoSheet.asStateFlow()

    private val _transactionFilter = MutableStateFlow("ALL")
    val transactionFilter: StateFlow<String> = _transactionFilter.asStateFlow()

    // Utility Bill state
    private val _utilityCategory = MutableStateFlow(ServiceType.ELECTRICITY)
    val utilityCategory: StateFlow<ServiceType> = _utilityCategory.asStateFlow()

    private val _consumerIdInput = MutableStateFlow("102938472")
    val consumerIdInput: StateFlow<String> = _consumerIdInput.asStateFlow()

    private val _isFetchingBill = MutableStateFlow(false)
    val isFetchingBill: StateFlow<Boolean> = _isFetchingBill.asStateFlow()

    private val _fetchedBill = MutableStateFlow<FetchedBill?>(null)
    val fetchedBill: StateFlow<FetchedBill?> = _fetchedBill.asStateFlow()

    private val _billFetchError = MutableStateFlow<String?>(null)
    val billFetchError: StateFlow<String?> = _billFetchError.asStateFlow()

    fun setUtilityCategory(category: ServiceType) {
        _utilityCategory.value = category
        _selectedService.value = category
        val ops = repository.getOperators(category)
        if (ops.isNotEmpty()) {
            _selectedOperator.value = ops.first()
        }
        _fetchedBill.value = null
        _billFetchError.value = null
        _consumerIdInput.value = when (category) {
            ServiceType.ELECTRICITY -> "102938472"
            ServiceType.GAS -> "88392019"
            ServiceType.WATER -> "55201938"
            ServiceType.CYLINDER -> "9876543210"
            else -> ""
        }
    }

    fun setConsumerIdInput(id: String) {
        _consumerIdInput.value = id
        _billFetchError.value = null
    }

    fun fetchDueBill(onSuccess: (() -> Unit)? = null) {
        val cid = _consumerIdInput.value.trim()
        if (cid.isEmpty()) {
            _billFetchError.value = "Please enter a valid Consumer / Account ID"
            return
        }

        viewModelScope.launch {
            _isFetchingBill.value = true
            _billFetchError.value = null
            delay(900)

            val match = SampleData.SAMPLE_BILLS.find {
                it.serviceType == _utilityCategory.value && (it.consumerId == cid || it.consumerId.contains(cid))
            }

            val bill = match ?: FetchedBill(
                billId = "BILL-${_utilityCategory.value.name.take(3)}-${Random.nextInt(1000, 9999)}",
                consumerId = cid,
                consumerName = "Consumer ($cid)",
                serviceType = _utilityCategory.value,
                providerName = _selectedOperator.value.name,
                billNumber = "BILL-${Random.nextInt(100000, 999999)}",
                billDate = "14 Sep 2026",
                dueDate = "05 Oct 2026",
                amountDue = when (_utilityCategory.value) {
                    ServiceType.ELECTRICITY -> 1480.0
                    ServiceType.GAS -> 620.0
                    ServiceType.WATER -> 340.0
                    ServiceType.CYLINDER -> 925.0
                    else -> 750.0
                },
                unitsConsumed = when (_utilityCategory.value) {
                    ServiceType.ELECTRICITY -> "185 kWh Units"
                    ServiceType.GAS -> "22 SCM Units"
                    ServiceType.WATER -> "15 Kilolitres"
                    else -> null
                },
                billingPeriod = "Aug 2026 - Sep 2026",
                earlyDiscount = 25.0,
                address = "Registered Consumer Address, ${_selectedCircle.value.name}"
            )

            _fetchedBill.value = bill
            _isFetchingBill.value = false
            onSuccess?.invoke()
        }
    }

    fun proceedToPayFetchedBill(onProceed: () -> Unit) {
        val bill = _fetchedBill.value ?: return
        _selectedService.value = bill.serviceType
        _targetNumber.value = bill.consumerId
        val op = SampleData.OPERATORS.find { it.name.equals(bill.providerName, ignoreCase = true) }
        if (op != null) _selectedOperator.value = op
        _customAmount.value = bill.amountDue.toInt().toString()
        _selectedPlan.value = null
        onProceed()
    }

    fun clearFetchedBill() {
        _fetchedBill.value = null
        _billFetchError.value = null
    }

    fun selectService(service: ServiceType) {
        _selectedService.value = service
        val ops = repository.getOperators(service)
        if (ops.isNotEmpty()) {
            _selectedOperator.value = ops.first()
        }
        _selectedPlan.value = null
        _customAmount.value = ""
        _targetNumber.value = ""
    }

    fun setTargetNumber(number: String) {
        _targetNumber.value = number
        // Simple auto-operator detection for mobile
        if (_selectedService.value == ServiceType.MOBILE_PREPAID || _selectedService.value == ServiceType.MOBILE_POSTPAID) {
            if (number.startsWith("98") || number.startsWith("99")) {
                val jio = SampleData.OPERATORS.find { it.id == "jio" }
                if (jio != null) _selectedOperator.value = jio
            } else if (number.startsWith("97") || number.startsWith("96")) {
                val airtel = SampleData.OPERATORS.find { it.id == "airtel" }
                if (airtel != null) _selectedOperator.value = airtel
            } else if (number.startsWith("95") || number.startsWith("94")) {
                val vi = SampleData.OPERATORS.find { it.id == "vi" }
                if (vi != null) _selectedOperator.value = vi
            }
        }
    }

    fun setOperator(operator: Operator) {
        _selectedOperator.value = operator
    }

    fun setCircle(circle: Circle) {
        _selectedCircle.value = circle
    }

    fun selectPlan(plan: RechargePlan) {
        _selectedPlan.value = plan
        _customAmount.value = plan.amount.toInt().toString()
    }

    fun setCustomAmount(amount: String) {
        _customAmount.value = amount
        _selectedPlan.value = null
    }

    fun setPlanSearchQuery(query: String) {
        _planSearchQuery.value = query
    }

    fun setSelectedCategory(category: PlanCategory?) {
        _selectedCategory.value = category
    }

    fun togglePlanComparison(plan: RechargePlan) {
        val current = _comparisonPlans.value.toMutableList()
        if (current.any { it.id == plan.id }) {
            current.removeAll { it.id == plan.id }
        } else {
            if (current.size >= 2) {
                current.removeAt(0)
            }
            current.add(plan)
        }
        _comparisonPlans.value = current
    }

    fun clearComparison() {
        _comparisonPlans.value = emptyList()
        _showComparisonSheet.value = false
    }

    fun setShowComparisonSheet(show: Boolean) {
        _showComparisonSheet.value = show
    }

    fun setUseWalletBalance(use: Boolean) {
        _useWalletBalance.value = use
    }

    fun setPaymentMethod(method: PaymentMethod) {
        _selectedPaymentMethod.value = method
    }

    fun applyPromo(promo: PromoCode?) {
        _appliedPromo.value = promo
        _showPromoSheet.value = false
    }

    fun setShowWalletSheet(show: Boolean) {
        _showWalletSheet.value = show
    }

    fun setShowPromoSheet(show: Boolean) {
        _showPromoSheet.value = show
    }

    fun setTransactionFilter(filter: String) {
        _transactionFilter.value = filter
    }

    fun calculateCheckout(): CheckoutCalculation {
        val baseAmount = _selectedPlan.value?.amount
            ?: _customAmount.value.toDoubleOrNull()
            ?: 0.0

        var discount = 0.0
        val promo = _appliedPromo.value
        if (promo != null && baseAmount >= promo.minAmount) {
            discount = if (promo.isPercentage) {
                ((baseAmount * promo.discountAmount) / 100.0).coerceAtMost(promo.maxDiscount)
            } else {
                promo.discountAmount
            }
        }

        val afterDiscount = (baseAmount - discount).coerceAtLeast(0.0)
        var walletDeduction = 0.0
        if (_useWalletBalance.value) {
            walletDeduction = walletBalance.value.coerceAtMost(afterDiscount)
        }

        val payable = (afterDiscount - walletDeduction).coerceAtLeast(0.0)
        val cashback = _selectedPlan.value?.cashbackOffer ?: 15.0

        return CheckoutCalculation(
            baseAmount = baseAmount,
            couponDiscount = discount,
            walletDeduction = walletDeduction,
            payableAmount = payable,
            estimatedCashback = cashback
        )
    }

    fun processRecharge(onSuccess: (RechargeTransaction) -> Unit) {
        val calc = calculateCheckout()
        val plan = _selectedPlan.value

        viewModelScope.launch {
            _isProcessingPayment.value = true
            _paymentProcessingStep.value = 0

            // Step 1: Gateway connection
            delay(700)
            _paymentProcessingStep.value = 1

            // Step 2: Bank / Wallet verification
            delay(800)
            _paymentProcessingStep.value = 2

            // Step 3: Operator plan activation
            delay(900)
            _paymentProcessingStep.value = 3
            delay(500)

            // Deduct wallet if used
            if (calc.walletDeduction > 0) {
                repository.deductWallet(calc.walletDeduction)
            }

            val txn = RechargeTransaction(
                transactionId = "VC-${Random.nextInt(10000000, 99999999)}",
                operatorRefId = "${_selectedOperator.value.name.take(3).uppercase()}-${Random.nextInt(100000, 999999)}",
                serviceType = _selectedService.value.name,
                targetNumber = _targetNumber.value.ifEmpty { "9876543210" },
                operatorName = _selectedOperator.value.name,
                circleName = _selectedCircle.value.name,
                planAmount = calc.baseAmount,
                walletDeduction = calc.walletDeduction,
                couponDiscount = calc.couponDiscount,
                finalAmountPaid = calc.payableAmount,
                paymentMethod = if (calc.walletDeduction > 0 && calc.payableAmount > 0) {
                    "Volt Wallet + ${_selectedPaymentMethod.value.title}"
                } else if (calc.payableAmount == 0.0) {
                    "Volt Wallet"
                } else {
                    _selectedPaymentMethod.value.title
                },
                status = "SUCCESS",
                planDescription = plan?.description ?: "Recharge of ₹${calc.baseAmount.toInt()}",
                validity = plan?.validity ?: "30 Days",
                dataAllowance = plan?.dataAllowance ?: "Standard",
                cashbackEarned = calc.estimatedCashback,
                timestamp = System.currentTimeMillis()
            )

            repository.addTransaction(txn)
            _lastTransaction.value = txn
            _isProcessingPayment.value = false
            onSuccess(txn)
        }
    }

    fun addMoneyToWallet(amount: Double) {
        repository.creditWallet(amount)
        _showWalletSheet.value = false
    }

    fun scratchCard(cardId: String) {
        repository.scratchCard(cardId)
    }

    fun toggleFavoriteBeneficiary(beneficiary: SavedBeneficiary) {
        viewModelScope.launch {
            repository.toggleFavorite(beneficiary)
        }
    }

    fun repeatRecharge(beneficiary: SavedBeneficiary, onReadyToPlan: () -> Unit) {
        val service = try {
            ServiceType.valueOf(beneficiary.serviceType)
        } catch (_: Exception) {
            ServiceType.MOBILE_PREPAID
        }
        _selectedService.value = service
        _targetNumber.value = beneficiary.numberOrId
        val op = SampleData.OPERATORS.find { it.name.equals(beneficiary.operatorName, ignoreCase = true) }
        if (op != null) _selectedOperator.value = op
        val circ = SampleData.CIRCLES.find { it.name.equals(beneficiary.circleName, ignoreCase = true) }
        if (circ != null) _selectedCircle.value = circ

        // Preselect a matching plan or set custom amount
        val matchingPlan = SampleData.ALL_PLANS.find {
            it.operatorId.equals(op?.id, ignoreCase = true) && it.amount == beneficiary.lastAmount
        }
        if (matchingPlan != null) {
            selectPlan(matchingPlan)
        } else {
            setCustomAmount(beneficiary.lastAmount.toInt().toString())
        }

        onReadyToPlan()
    }

    fun getFilteredPlans(): List<RechargePlan> {
        val opId = _selectedOperator.value.id
        val plans = repository.getPlansForOperator(opId)
        val query = _planSearchQuery.value.trim().lowercase()
        val cat = _selectedCategory.value

        return plans.filter { plan ->
            val matchesCategory = cat == null || plan.category == cat
            val matchesQuery = query.isEmpty() ||
                    plan.amount.toInt().toString().contains(query) ||
                    plan.dataAllowance.lowercase().contains(query) ||
                    plan.validity.lowercase().contains(query) ||
                    plan.description.lowercase().contains(query) ||
                    plan.ottSubscriptions.any { it.lowercase().contains(query) }
            matchesCategory && matchesQuery
        }
    }

    fun getAvailablePromoCodes(): List<PromoCode> = repository.getPromoCodes()
    fun getAvailableCircles(): List<Circle> = repository.getCircles()
    fun getOperatorsForCurrentService(): List<Operator> = repository.getOperators(_selectedService.value)
}
